# finartz-kctl-yaml

Finartz ekipleri tarafından kullanılan Kubernetes namespace'lerine deployment yapılırken, 
kctl ile kullanılacak .yaml dosyalarının bulunduğu repo.

## Kullanım
- master'dan pull alınır.
- ilgili yaml dosyasında sürüm(ler) güncellenir.
- kctl ile apply edilir. `kctl -c {namespace_adı}-dev apply -f dev/{namespace_adı}.yaml`
- commit & push.

kctl kullanımı için: http://git.app.gittigidiyor.net/gg/kctl/blob/master/README.md

örnek kctl apply k      omutu: `kctl -c fa0-dev apply -f dev/fa0.yaml`