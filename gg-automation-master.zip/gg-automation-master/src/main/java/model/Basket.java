package model;

import java.util.ArrayList;
import java.util.List;

public class Basket {

    private List<String> basketId = new ArrayList<>();
    private List<String> productIdInBasket = new ArrayList<>();
    private List<String> variantIdInBasket = new ArrayList<>();

    @Override
    public String toString() {
        return "Basket{" +
                "basketId=" + basketId +
                ", productId=" + productIdInBasket +
                ", variantId=" + variantIdInBasket +
                '}';
    }

    public List<String> getBasketId() {
        return basketId;
    }

    public void setBasketId(List<String> basketId) {
        this.basketId = basketId;
    }

    public List<String> getProductIdInBasket() {
        return productIdInBasket;
    }

    public void setProductIdInBasket(List<String> productId) {
        this.productIdInBasket = productId;
    }

    public List<String> getVariantIdInBasket() {
        return variantIdInBasket;
    }

    public void setVariantIdInBasket(List<String> variantId) {
        this.variantIdInBasket = variantId;
    }


}
