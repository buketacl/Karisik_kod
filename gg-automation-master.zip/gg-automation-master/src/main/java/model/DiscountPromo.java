package model;

public class DiscountPromo {

    private  String promoID ;
    private  String promoPrice ;
    private  String promoPercent ;

    public DiscountPromo() {
    }



    public  String getPromoID() {
        return promoID;
    }

    public void setPromoID(String promoID) {
        this.promoID = promoID;
    }

    public  String getPromoPrice() {
        return promoPrice;
    }

    public  void setPromoPrice(String promoPrice) {
        this.promoPrice = promoPrice;
    }

    public String getPromoPercent() {
        return promoPercent;
    }

    public void setPromoPercent(String promoPercent) {
       this.promoPercent = promoPercent;
    }

    @Override
    public String toString() {
        return "DiscountPromo{" +
                "promoID='" + promoID + '\'' +
                ", promoPrice='" + promoPrice + '\'' +
                ", promoPercent='" + promoPercent + '\'' +
                '}';
    }
}
