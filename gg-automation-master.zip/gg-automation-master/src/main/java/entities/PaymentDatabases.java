package entities;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.BasePage;
import pages.PaymentSuccessPage;
import pages.ProductDetailPage;

import static entities.utility.PaymentDBUtility.*;


import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class PaymentDatabases extends BasePage {
    public PaymentDatabases(WebDriver driver, WebDriverWait wait) throws InterruptedException, SQLException, ClassNotFoundException {
        super(driver, wait);
    }


    public static Connection dbConnection() throws InterruptedException, ClassNotFoundException, SQLException {
        //Connection URL Syntax: "jdbc:mysql://ipaddress:portnumber/db_name"
        String dbUrl = "jdbc:mysql://oslyvtpmyq01.host.gittigidiyor.net:3306/gg";
        //Database Username
        String username = "tcakiroglu";
        //Database Password
        String password = "b535ti44Hs4M";
        //Load mysql jdbc driver
        Class.forName("com.mysql.jdbc.Driver");

        //Create Connection to DB
        return DriverManager.getConnection(dbUrl, username, password);

    }

    public void checkSatisDB() throws SQLException, ClassNotFoundException, InterruptedException {

        Connection connection = dbConnection();
        Statement stmt = connection.createStatement();

        for (String saleCode : PaymentSuccessPage.saleCode) {

            String satisDBSql = satisDB_Sql.replace(":saleCode", saleCode);
            ResultSet satisDBresult = stmt.executeQuery(satisDBSql);

            // While Loop to iterate through all data and print results
            while (satisDBresult.next()) {
                System.out.println("***SatısDB***");
                satisDB_payprice = satisDBresult.getString(1);
                satisDB_unitPrice = satisDBresult.getString(2) + " TL";
                satisDB_count = satisDBresult.getString(3) + " Adet";

                System.out.println("Pay price: " + satisDB_payprice + "\n" + "Birim fiyat: " + satisDB_unitPrice + " \n" + "Adet: " + satisDB_count);

                satisDB_payPriceTotal = satisDB_payPriceTotal.add(new BigDecimal(satisDB_payprice));

            }

        }

        String satisDB_PriceTotal = String.valueOf(satisDB_payPriceTotal).replace(".", "");
        System.out.println(satisDB_PriceTotal);
        System.out.println(PaymentSuccessPage.totalPrice);

        Assert.assertEquals(satisDB_PriceTotal, PaymentSuccessPage.totalPrice);
        connection.close();

    }


    public void checkSalePaymentItemDB(String channel) throws SQLException, ClassNotFoundException, InterruptedException {

        Connection connection = dbConnection();
        Statement stmt = connection.createStatement();
        String salePaymentItemDBSql = null;
        for (String saleCode : PaymentSuccessPage.saleCode) {
            if (channel == "pos") {
                salePaymentItemDBSql = pos_salePaymentItemDB_Sql.replace(":saleCode", saleCode);
            } else if (channel == "mobilexp") {
                salePaymentItemDBSql = mobilexp_salePaymentItemDB_Sql.replace(":saleCode", saleCode);
            } else if (channel == "bkm") {
                salePaymentItemDBSql = bkm_salePaymentItemDB_Sql.replace(":saleCode", saleCode);
            } else if (channel == "grnt_crd") {
                salePaymentItemDBSql = grnt_crd_salePaymentItemDB_Sql.replace(":saleCode", saleCode);
            }
            ResultSet salePaymentItemDBresult = stmt.executeQuery(salePaymentItemDBSql);
            while (salePaymentItemDBresult.next()) {

                System.out.println("\n" + "***SalePaymentItemDB***");
                salePaymentItemDB_paidAmount = salePaymentItemDBresult.getString(1);
                salePaymentItemDB_paymentID = salePaymentItemDBresult.getString(2);
                salePaymentItemDB_ggCommissionRate = salePaymentItemDBresult.getString(3);
                salePaymentItemDB_saleDiscountAmount = salePaymentItemDBresult.getString(4);
                salePaymentItemDB_doCommissionRate = salePaymentItemDBresult.getString(5);
                if (salePaymentItemDBresult.getString(6) != null) {
                    salePaymentItemDB_shippingItemID.add(salePaymentItemDBresult.getString(6));
                }

                System.out.println("Paid amount: " + salePaymentItemDB_paidAmount + " \n " + "Payment id: " + salePaymentItemDB_paymentID + " \n" + "GG commission rate: " + salePaymentItemDB_ggCommissionRate + "\n "
                        + "Sale discount amount: " + salePaymentItemDB_saleDiscountAmount + "\n " + "Do commission rate: " + salePaymentItemDB_doCommissionRate + "\n " + "Shipping item id: " + salePaymentItemDB_shippingItemID);

                salePaymentItemDB_payPriceTotal = salePaymentItemDB_payPriceTotal.add(new BigDecimal(salePaymentItemDB_paidAmount));

            }
        }
        salePaymentItemDB_payPriceTotal = salePaymentItemDB_payPriceTotal.setScale(2, BigDecimal.ROUND_HALF_UP);
        String salePaymentItemDB_paidPrice = String.valueOf(salePaymentItemDB_payPriceTotal).replace(".", "");
        Assert.assertEquals(salePaymentItemDB_paidPrice, PaymentSuccessPage.totalPrice);
        connection.close();

    }

    public void checkPaymentDB(String channel) throws SQLException, ClassNotFoundException, InterruptedException {

        Connection connection = dbConnection();
        Statement stmt = connection.createStatement();
        String paymentDB_Sql = null;
        if (channel == "pos") {
            paymentDB_Sql = pos_paymentDB_Sql.replace(":paymentID", salePaymentItemDB_paymentID);
        } else if (channel == "mobilexp") {
            paymentDB_Sql = mobilexp_paymentDB_Sql.replace(":paymentID", salePaymentItemDB_paymentID);
        } else if (channel == "bkm") {
            paymentDB_Sql = bkm_paymentDB_Sql.replace(":paymentID", salePaymentItemDB_paymentID);
        } else if (channel == "grnt_crd") {
            paymentDB_Sql = grnt_crd_paymentDB_Sql.replace(":paymentID", salePaymentItemDB_paymentID);
        }

        ResultSet paymentDBresult = stmt.executeQuery(paymentDB_Sql);
        while (paymentDBresult.next()) {
            System.out.println("***PaymentDB***");
            paymentDB_paymentCode = paymentDBresult.getString(1);
            paymentDB_discountAmount = paymentDBresult.getString(2);
            paymentDB_paidAmount = paymentDBresult.getString(3).replace(".", "");
            paymentDB_installment = paymentDBresult.getString(4);
            paymentDB_installmentCommissionRate = paymentDBresult.getString(5);

            System.out.println("Payment Code: " + paymentDB_paymentCode + " \n " + "Discount amount: " + paymentDB_discountAmount + "\n " + "Paid amount: " + paymentDB_paidAmount + " \n" + "Installment: " + paymentDB_installment
                    + "\n " + "Installment commission rate: " + paymentDB_installmentCommissionRate);
            Assert.assertEquals(PaymentSuccessPage.totalPrice, paymentDB_paidAmount);
            Assert.assertEquals(installment1, paymentDB_installment);

        }
        connection.close();
    }

    public void checkPaymentLogDB() throws SQLException, ClassNotFoundException, InterruptedException {

        Connection connection = dbConnection();
        Statement stmt = connection.createStatement();

        paymentLogDB_Sql = paymentLogDB_Sql.replace(":paymentCode", paymentDB_paymentCode);
        ResultSet paymentLogDBresult = stmt.executeQuery(paymentLogDB_Sql);
        while (paymentLogDBresult.next()) {
            System.out.println("***Payment_LogDB***");
            paymentLogDB_price = paymentLogDBresult.getString(1);
            paymentLogDB_paidPrice = paymentLogDBresult.getString(2).replace(".", "");
            paymentLogDB_installmentNumber = paymentLogDBresult.getString(3);
            paymentLogDB_paymentType = paymentLogDBresult.getString(4);

            System.out.println("Price: " + paymentLogDB_price + " \n " + "Paid price: " + paymentLogDB_paidPrice + "\n " + "Installment number: " + paymentLogDB_installmentNumber + " \n" + "Payment type: " + payment_type);
            Assert.assertEquals(payment_type, paymentLogDB_paymentType);
            Assert.assertEquals(PaymentSuccessPage.totalPrice, paymentLogDB_paidPrice);
            Assert.assertEquals(installment1, paymentLogDB_installmentNumber);

        }
        connection.close();
    }

    public void checkShippingPaymentItemDB(String channel) throws SQLException, ClassNotFoundException, InterruptedException {

        Connection connection = dbConnection();
        Statement stmt = connection.createStatement();
        String shippingPaymentItemDBSql = null;
        for (String shippingID : salePaymentItemDB_shippingItemID) {
            if (channel == "pos") {
                shippingPaymentItemDBSql = pos_shippingPaymentItemDB_Sql.replace(":shippingID", shippingID);
            } else if (channel == "mobilexp") {
                shippingPaymentItemDBSql = mobilexp_shippingPaymentItemDB_Sql.replace(":shippingID", shippingID);
            } else if (channel == "bkm") {
                shippingPaymentItemDBSql = bkm_shippingPaymentItemDB_Sql.replace(":shippingID", shippingID);
            } else if (channel == "grnt_crd") {
                shippingPaymentItemDBSql = grnt_crd_shippingPaymentItemDB_Sql.replace(":shippingID", shippingID);
            }

            ResultSet shippingDBResult = stmt.executeQuery(shippingPaymentItemDBSql);
            while (shippingDBResult.next()) {
                System.out.println("***Shipping_Payment_ItemDB***");
                shippingPaymentItemDB_paymentItemID = shippingDBResult.getString(1);
                shippingPaymentItemDB_shippingFirmCode = shippingDBResult.getString(2);
                shippingPaymentItemDB_price = shippingDBResult.getString(3);
                shippingPaymentItemDB_paidAmount = shippingDBResult.getString(4);

                totalcargoPriceDB = totalcargoPriceDB.add(new BigDecimal(shippingPaymentItemDB_paidAmount));
                System.out.println("Payment item id: " + shippingPaymentItemDB_paymentItemID + "\n  " + "Shipping firm code: " + shippingPaymentItemDB_shippingFirmCode + " \n" + "Price: " + shippingPaymentItemDB_price + "\n " + "Paid amount: " + totalcargoPriceDB);

            }
        }

        totalcargoPriceDB = totalcargoPriceDB.setScale(2, BigDecimal.ROUND_HALF_UP);
        String replaceTotalCargoPriceDB = String.valueOf(totalcargoPriceDB).replace(".", "");
        Integer TotalCargoPriceDB = Integer.valueOf(replaceTotalCargoPriceDB);
        // Assert.assertEquals(TotalCargoPriceDB, totalCargoFee);

        connection.close();


    }
}





