package entities.utility;

import java.util.ArrayList;
import java.util.List;

public class GittigidiyorDBUtility {

    public static  String sepetDB_Sql = "select urunId,sepetId,UrunRetailVariantID from gg.Sepet where urunId =':urunId'and memberId =':memberId';";
    public static final List<String> sepetDB_urunID = new ArrayList<>();
    public static final List<String> sepetDB_urunVariantID = new ArrayList<>();
    public static List<String> sepetDB_sepetID = new ArrayList<>() ;
    public static List<String> addressDB_addressID = new ArrayList<>();

    public static String discountPromoDB_Sql = " select DPromoID, `DPromoPercent`,DPromoPrice from promotion.DiscountPromo where DPromoID =':promoID';";


}
