package entities.utility;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class PaymentDBUtility {

    public static String satisDB_Sql = "select pay_price , birim_fiyat , adet from gg.satis where satis_code =':saleCode' order by end_date DESC;";
    public static String paymentLogDB_Sql = "select price,paid_price, installment_number,payment_type from gg.payment_log where payment_code = ':paymentCode'";



    public static String pos_salePaymentItemDB_Sql = "select paid_amount,payment_id,gg_commission_rate, sale_discount_amount, do_commission_rate , shipping_payment_item_id " +
            "from paymaster.`pos_sale_payment_item` where sale_code=':saleCode' ;";

    public static String pos_paymentDB_Sql = "select payment_code, discount_amount, paid_amount, installment, installment_commission_rate from paymaster.pos_payment where payment_id =':paymentID';";
    public static String pos_shippingPaymentItemDB_Sql = "select payment_item_id, Shipping_firm_code, price, paid_amount from paymaster.pos_shipping_payment_item where payment_item_id =':shippingID';";


    public static String bkm_salePaymentItemDB_Sql = "select paid_amount,payment_id,gg_commission_rate, sale_discount_amount, do_commission_rate , shipping_payment_item_id " +
            "from paymaster.`bkm_sale_payment_item` where sale_code=':saleCode' ;";
    public static String bkm_paymentDB_Sql = "select payment_code, discount_amount, paid_amount, installment, installment_commission_rate from paymaster.bkm_payment where payment_id =':paymentID';";
    public static String bkm_shippingPaymentItemDB_Sql = "select payment_item_id, Shipping_firm_code, price, paid_amount from paymaster.bkm_shipping_payment_item where payment_item_id =':shippingID';";


    public static String mobilexp_salePaymentItemDB_Sql = "select paid_amount,payment_id,gg_commission_rate, sale_discount_amount, do_commission_rate , shipping_payment_item_id " +
            "from paymaster.`mobilexp_sale_payment_item` where sale_code=':saleCode' ;";
    public static String mobilexp_paymentDB_Sql = "select payment_code, discount_amount, paid_amount, installment, installment_commission_rate from paymaster.mobilexp_payment where payment_id =':paymentID';";
    public static String mobilexp_shippingPaymentItemDB_Sql = "select payment_item_id, Shipping_firm_code, price, paid_amount from paymaster.mobilexp_shipping_payment_item where payment_item_id =':shippingID';";

    public static String grnt_crd_salePaymentItemDB_Sql = "select paid_amount,payment_id,gg_commission_rate, sale_discount_amount, do_commission_rate , shipping_payment_item_id " +
            "from paymaster.`grnt_crd_sale_payment_item` where sale_code=':saleCode' ;";
    public static String grnt_crd_paymentDB_Sql = "select payment_code, discount_amount, paid_amount from paymaster.grnt_crd_payment where payment_id =':paymentID';";
    public static String grnt_crd_shippingPaymentItemDB_Sql = "select payment_item_id, Shipping_firm_code, price, paid_amount from paymaster.grnt_crd_shipping_payment_item where payment_item_id =':shippingID';";


    public static String installment1 ="1";
    public static String installment9 ="6";
    public static String payment_type = "CC";
    public static String payment_type3D = "3D";
    public static String payment_type_Mobex = "ME";
    public static String payment_type_Mobex3D = "M3";
    public static String payment_type_bkm = "BE";
    public static String payment_type_GC = "GC";
    public static String satisDB_payprice;
    public static String satisDB_count;
    public static String satisDB_unitPrice;
    public static BigDecimal satisDB_payPriceTotal = BigDecimal.ZERO;
    public static BigDecimal totalcargoPriceDB = BigDecimal.ZERO;

    public static String salePaymentItemDB_paidAmount;
    public static String salePaymentItemDB_paymentID;
    public static String salePaymentItemDB_ggCommissionRate;
    public static String salePaymentItemDB_saleDiscountAmount;
    public static String salePaymentItemDB_doCommissionRate;
    //public static String salePaymentItemDB_shippingItemID;
    public static final Set<String> salePaymentItemDB_shippingItemID = new HashSet<>();
    public static String salePaymentItemDB_paidPrice;
    public static BigDecimal salePaymentItemDB_payPriceTotal = BigDecimal.ZERO;

    public static String paymentDB_paymentCode;
    public static String paymentDB_discountAmount;
    public static String paymentDB_paidAmount;
    public static String paymentDB_installment;
    public static String paymentDB_installmentCommissionRate;

    public static String paymentLogDB_price;
    public static String paymentLogDB_paidPrice;
    public static String paymentLogDB_paymentType;
    public static String paymentLogDB_installmentNumber;

    public static String shippingPaymentItemDB_paymentItemID;
    public static String shippingPaymentItemDB_shippingFirmCode;
    public static String shippingPaymentItemDB_price;
    public static String shippingPaymentItemDB_paidAmount;

}
