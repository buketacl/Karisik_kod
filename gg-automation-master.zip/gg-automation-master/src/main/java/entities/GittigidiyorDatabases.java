package entities;

import model.DiscountPromo;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.BasePage;
import pages.ProductDetailPage;
import java.sql.*;
import java.util.*;

import static entities.utility.GittigidiyorDBUtility.*;

public class GittigidiyorDatabases extends BasePage {

    public GittigidiyorDatabases(WebDriver driver, WebDriverWait wait) throws InterruptedException, SQLException, ClassNotFoundException {
        super(driver, wait);
    }

    public static Connection dbConnection() throws InterruptedException, ClassNotFoundException, SQLException {
        //Connection URL Syntax: "jdbc:mysql://ipaddress:portnumber/db_name"
        String dbUrl = "jdbc:mysql://oslyvtpmyq01.host.gittigidiyor.net:3306/gg";
        //Database Username
        String username = "tcakiroglu";
        //Database Password
        String password = "b535ti44Hs4M";
        //Load mysql jdbc driver
        Class.forName("com.mysql.jdbc.Driver");

        //Create Connection to DB
        return DriverManager.getConnection(dbUrl, username, password);

    }

    public List<String> checkBasketDB(String memberId) throws SQLException, ClassNotFoundException, InterruptedException {

        Connection connection = dbConnection();
        Statement stmt = connection.createStatement();
        HashSet<String> productIds = new HashSet<>(ProductDetailPage.productIds);
        for (String urunId : productIds) {
            String replacesepetDB_Sql = sepetDB_Sql.replace(":urunId", urunId).replace(":memberId", memberId);
            ResultSet sepetDBResult = stmt.executeQuery(replacesepetDB_Sql);

            while (sepetDBResult.next()) {
                System.out.println("***BasketDB***");
                sepetDB_urunID.add(sepetDBResult.getString(1));
            }
            System.out.println("Urun Id:" + sepetDB_urunID + "Sepet Id:" + sepetDB_sepetID);

        }
        connection.close();
        Collections.sort(sepetDB_urunID);
        return sepetDB_urunID;
    }
    public List<String> checkBasketDBWithVariant(String productID, String memberId) throws SQLException, ClassNotFoundException, InterruptedException {

        Connection connection = dbConnection();
        Statement stmt = connection.createStatement();
        String replaceSepetDB_Sql =  sepetDB_Sql.replace(":urunId", productID).replace(":memberId", memberId);
        ResultSet sepetDBResult = stmt.executeQuery(replaceSepetDB_Sql);
        while (sepetDBResult.next()) {
            System.out.println("***BasketDB***");
            sepetDB_urunVariantID.add(sepetDBResult.getString(3));

            System.out.println("Urun Id:" + productID + "UrunVariantID:" + sepetDB_urunVariantID);

        }
        connection.close();
        return sepetDB_urunVariantID;

    }
    public List<String> getBasketID( String memberId) throws SQLException, ClassNotFoundException, InterruptedException {

        Connection connection = dbConnection();
        Statement stmt = connection.createStatement();
        HashSet<String> productIds = new HashSet<>(ProductDetailPage.productIds);
        sepetDB_sepetID = new ArrayList<>();
        for (String urunId : productIds) {
            String replacesepetDB_Sql = sepetDB_Sql.replace(":urunId", urunId).replace(":memberId", memberId);
            ResultSet sepetDBResult = stmt.executeQuery(replacesepetDB_Sql);
            while (sepetDBResult.next()) {
                System.out.println("***BasketDB***");
                sepetDB_sepetID.add(sepetDBResult.getString(2));

                System.out.println("Sepet Ids:"+ sepetDB_sepetID);

            }
        }
        connection.close();
        return sepetDB_sepetID;

    }

    public DiscountPromo discountPromoDB(String promoID) throws SQLException, ClassNotFoundException, InterruptedException {

        Connection connection = dbConnection();
        Statement stmt = connection.createStatement();
        DiscountPromo discountPromo = new DiscountPromo();
        String replaceDiscountPromoDB_Sql = discountPromoDB_Sql.replace(":promoID", promoID);
        ResultSet discountPromoDBResult = stmt.executeQuery(replaceDiscountPromoDB_Sql);
        while (discountPromoDBResult.next()) {
            System.out.println("***DiscountPromoDB***");
            discountPromo.setPromoID(discountPromoDBResult.getString(1));
            discountPromo.setPromoPercent(discountPromoDBResult.getString(2));
            discountPromo.setPromoPrice(discountPromoDBResult.getString(3));

            System.out.println("Promo Id:" + discountPromo.getPromoID() + "Percent:" + discountPromo.getPromoPercent() + "Price:" + discountPromo.getPromoPrice());

        }
        connection.close();
       return discountPromo;
    }
}
