package pages;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.List;

public class PaymentSuccessPage extends BasePage {
    public PaymentSuccessPage(WebDriver driver, WebDriverWait wait) {
        super(driver, wait);
    }

    public static final List<String> saleCode = new ArrayList<>();
    public static final List<String> counts = new ArrayList<>();
    public static final List<String> unitPrice = new ArrayList<>();
    public static String totalPrice;


    public void getSaleCode(String id) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div/ul/li/span")));
        saleCode.add(driver.findElement(By.xpath("//div[@id='product-info-" + id + "']/div[3]/div/p")).getText());
        System.out.println(saleCode);

    }

    public void getCount(String id) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div/ul/li/span")));
        counts.add(driver.findElement(By.xpath("//div[@id='product-info-" + id + "']/div[2]/div/span")).getText());
        System.out.println(counts);

    }

    public void getUnitPrice(String id) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div/ul/li/span")));
        unitPrice.add(driver.findElement(By.xpath(" //*[@id=\"product-info-" + id + "\"]/div[2]/div/strong")).getText().replace(",", "."));
        System.out.println(unitPrice);
    }

    public void getTotalPrice() {
        if ((PaymentPage.cargoModel.equals("Ücretsiz") || PaymentPage.cargoModel.equals("Alıcı Kapıda Öder" ) )&& (PaymentPage.discountInPayment.equals("null"))) {
            totalPrice = driver.findElement(By.xpath("//div[2]/div/ul/li/span")).getText().replace(",", "").replace(".", "");
            totalPrice = totalPrice.substring(0, totalPrice.length() - 3);
        }
        else if((PaymentPage.cargoModel.equals("Aynı Gün Teslimat") || PaymentPage.cargoModel.equals("Alıcı Sepette Öder" )) && (!PaymentPage.discountInPayment.equals("null"))){
            totalPrice = driver.findElement(By.xpath("//li[4]/span")).getText().replace(",", "").replace(".", "");
            totalPrice = totalPrice.substring(0, totalPrice.length() - 3);
        }
        else if((PaymentPage.cargoModel.equals("Aynı Gün Teslimat") || PaymentPage.cargoModel.equals("Alıcı Sepette Öder" )) && (PaymentPage.discountInPayment.equals("null"))){
            totalPrice = driver.findElement(By.xpath("//li[2]/span")).getText().replace(",", "").replace(".", "");
            totalPrice = totalPrice.substring(0, totalPrice.length() - 3);
        }
        else if((PaymentPage.cargoModel.equals("Ücretsiz") || PaymentPage.cargoModel.equals("Alıcı Kapıda Öder" )) && (!PaymentPage.discountInPayment.equals("null"))){
            totalPrice = driver.findElement(By.xpath("//li[3]/span")).getText().replace(",", "").replace(".", "");
            totalPrice = totalPrice.substring(0, totalPrice.length() - 3);
        }
        System.out.println(totalPrice);
    }

    public void checkTotalPriceAtPaymentSuccess() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div/ul/li/span")));
        if (PaymentPage.cargoModel.equals("Ücretsiz") || PaymentPage.cargoModel.equals("Alıcı Kapıda Öder")) {
            totalPrice = driver.findElement(By.xpath("//div[2]/div/ul/li/span")).getText().replace(",", "").replace(".", "");
        } else {
            totalPrice = driver.findElement(By.xpath("//div[2]/div/ul/li[2]/span")).getText().replace(",", "").replace(".", "");

        }
        Assert.assertEquals(PaymentPage.paidAmount, totalPrice);

    }

    public void checkDiscountInPaymentSuccess() {
        //paymentpage selectdiscount methodu calıstırılmıs olmalı.
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div/ul/li/span")));
        if (PaymentPage.cargoModel.equals("Ücretsiz") || PaymentPage.cargoModel.equals("Alıcı Kapıda Öder")) {
            String discountInPaymentSuccess = driver.findElement(By.xpath("//li[2]/span")).getText().replace(".", "").replace(" TL anında indirim", "").replace(",", "");
            Assert.assertEquals(PaymentPage.discountInPayment, discountInPaymentSuccess);
        } else {
            String discountInPaymentSuccess = driver.findElement(By.xpath("//li[3]/span")).getText().replace(".", "").replace(" TL anında indirim", "").replace(",", "");
            Assert.assertEquals(PaymentPage.discountInPayment, discountInPaymentSuccess);
        }


    }

    public void checkCargoModelInPaymentSuccess(String productId, String cargoDetail) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='payment-information']/div[2]/div/h3")));
        if (cargoDetail.equals("Alıcı Sepette Öder")) {
            String cargoDetailInPaymentSuccess = driver.findElement(By.xpath("//div[@id='product-info-" + productId + "']/div[2]/div/span[2]/span")).getText();
            Assert.assertEquals(cargoDetailInPaymentSuccess, cargoDetail);
        } else {
            String cargoDetailInPaymentSuccess = driver.findElement(By.xpath("//div[@id='product-info-" + productId + "']/div[2]/div/span[2]")).getText();
            Assert.assertEquals(cargoDetailInPaymentSuccess, cargoDetail);
        }
    }
}
//cargoDetail.equals("Ücretsiz Kargo") || cargoDetail.equals("Alıcı Kapıda Öder")