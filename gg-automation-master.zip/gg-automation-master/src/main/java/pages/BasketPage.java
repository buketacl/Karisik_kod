package pages;

import entities.GittigidiyorDatabases;
import entities.PaymentDatabases;
import entities.PaymentDatabases;
import model.DiscountPromo;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.server.handler.FindElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.*;

public class BasketPage extends BasePage {
    public BasketPage(WebDriver driver, WebDriverWait wait) throws InterruptedException, SQLException, ClassNotFoundException {
        super(driver, wait);
    }


    String basketUrl = "https://www.gittigidiyor.com/sepetim";
    public static String  discountInBasket;
    GittigidiyorDatabases ggDB = new GittigidiyorDatabases(driver,wait);


    public void goToBasket() {

        driver.get(basketUrl);

    }

    public void goToBasketFromPDP(){

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"header_wrapper\"]/div[4]/div[3]")));
        driver.findElement(By.xpath("//*[@id=\"header_wrapper\"]/div[4]/div[3]")).click();
        driver.findElement(By.xpath("//div[@id='header_wrapper']/div[4]/div[3]/div/a")).click();

    }


    public void goToAddress() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[3]/div/div/div/div[5]/div[3]/input")));
        driver.findElement(By.xpath("//div[3]/div/div/div/div[5]/div[3]/input")).click();
    }

    public void selectDiscountInBasket(String discountValue) {

        Select discount = new Select(driver.findElement(By.name("discountId")));
        discount.selectByValue(discountValue);
        discountInBasket = driver.findElement(By.xpath("//*[@id=\"submit-cart\"]/div/div/div[3]/div/div[1]/div/div[5]/div[1]/div/ul/li[3]/div[2]")).getText().replace(" TL", "").replace("-", "").replace(".", "").replace(",", "");


    }

    public void checkDiscountInBasket(String discountId) throws InterruptedException, SQLException, ClassNotFoundException {

        DiscountPromo discountPromo;
        String productTotalPrice;
        String calculatedDiscount;
        String percent;
        BigDecimal bigCalculatedDiscount;

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cart-continue-button-container")));
        discountPromo = ggDB.discountPromoDB(discountId);
        if(driver.findElement(By.xpath("//*[@id=\"submit-cart\"]/div/div/div[3]/div/div[1]/div/div[5]/div[1]/div/ul/li[3]/div[2]")).isDisplayed()) {
            if (Double.valueOf(discountPromo.getPromoPrice()) > 0) {
                Assert.assertEquals(discountInBasket, discountPromo.getPromoPrice().replace(".", "").replace(",", ""));
            }
            else if(Double.valueOf(discountPromo.getPromoPercent()) > 0){
                productTotalPrice =   driver.findElement(By.xpath("//*[@id=\"submit-cart\"]/div/div/div[3]/div/div[1]/div/div[5]/div[1]/div/ul/li[1]/div[2]")).getText().replace(",","").replace(".","").replace(" TL", "");
                percent =  discountPromo.getPromoPercent();
                BigDecimal bigProductTotalPrice = new BigDecimal(productTotalPrice);
                BigDecimal bigPercent = new BigDecimal(percent);
                bigCalculatedDiscount = bigProductTotalPrice.multiply(bigPercent).divide(BigDecimal.valueOf(100));
                calculatedDiscount = String.valueOf(bigCalculatedDiscount);
                calculatedDiscount = calculatedDiscount.substring(0,calculatedDiscount.length()-3);
                Assert.assertEquals(discountInBasket, calculatedDiscount);


            }
        }
        else{
            Assert.fail("İndirim alanı gelmiyor.");
        }
        System.out.println(discountPromo);


    }

    public void increaseProduct(String count) throws InterruptedException, SQLException, ClassNotFoundException {

        for (String basketId : ggDB.getBasketID("1008621353")) {
            Select increase = new Select(driver.findElement(By.xpath("//div[@id='cart-item-"+basketId+"']/div[2]/div[4]/div/div[2]/select")));
            increase.selectByValue(count);
        }

    }
    public void deleteItem() throws InterruptedException, SQLException, ClassNotFoundException {

        for ( String basketId : ggDB.getBasketID("1008621353")){
            driver.findElement(By.xpath("//div[@id='cart-item-"+basketId+"']/div[2]/div[3]/div/div[2]/div/a/i")).click();
        }
    }

    public void checkProductInBasket() throws InterruptedException, SQLException, ClassNotFoundException {
        //ProductDetailPage getProductIds methodu calıstırılmıs olmalı.
        GittigidiyorDatabases ggDB = new GittigidiyorDatabases(driver,wait);
        Collections.sort(ProductDetailPage.productIds);
        Assert.assertEquals(ProductDetailPage.productIds,ggDB.checkBasketDB("1008621353"));

    }

    public void checkIsBasketEmpty(){

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='empty-cart-container']/div/div/div/div[2]/h2")));
        String emptyMessageInBasket = driver.findElement(By.xpath("//div[@id='empty-cart-container']/div/div/div/div[2]/h2")).getText();
        Assert.assertEquals(emptyMessageInBasket,"Sepetinizde ürün bulunmamaktadır.");
    }

    public void checkProductPrice() throws InterruptedException, SQLException, ClassNotFoundException {
        Thread.sleep(1500);
        String productsPrice;
        String productPriceOnSubmitCart;
        BigDecimal bigProductPrice;
        BigDecimal productTotalPrice = new BigDecimal(0);
        for (String basketId : ggDB.getBasketID("1008621353")){
            productsPrice = driver.findElement(By.xpath("//div[@id='cart-item-"+basketId+"']/div/div[5]/div/div/strong")).getText()
                    .replace(".","").replace(",", "").replace(" TL","");
            bigProductPrice = new BigDecimal(productsPrice);
            productTotalPrice =  productTotalPrice.add(bigProductPrice);
        }
        productsPrice = String.valueOf(productTotalPrice);
        productPriceOnSubmitCart = driver.findElement(By.xpath("//form[@id='submit-cart']/div/div[2]/div[3]/div/div/div/div[5]/div/div/ul/li/div[2]")).getText()
                .replace(".","").replace(",", "").replace(" TL","");
        Assert.assertEquals(productsPrice,productPriceOnSubmitCart);
        bigProductPrice = new BigDecimal(0);


    }

    public void checkCargoModelAtBasket(String expectedCargoModel) throws InterruptedException {
        Thread.sleep(1500);
        String cargoModelAtBasket = driver.findElement(By.xpath("//*[@id=\"submit-cart\"]/div/div/div[3]/div/div[1]/div/div[5]/div[1]/div/ul/li[2]/div[2]")).getText();
        Assert.assertEquals(cargoModelAtBasket, expectedCargoModel);

    }

    public void checkTotalNumberOfProductInBasket(String totalNumberOfProduct) throws InterruptedException {
        Thread.sleep(1000);
        String numberOfProduct = driver.findElement(By.xpath("//form[@id='submit-cart']/div/div[2]/div[3]/div/div/div/div[5]/div/div/ul/li/div")).getText();
        Assert.assertEquals(totalNumberOfProduct, numberOfProduct);

    }

    public void goToAddressWithGuestUser() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[1]/div[3]/div[1]/div/div/div/div/div/div[2]/input")));
        driver.findElement(By.xpath("//div[1]/div[3]/div[1]/div/div/div/div/div/div[2]/input")).click();
    }
}
