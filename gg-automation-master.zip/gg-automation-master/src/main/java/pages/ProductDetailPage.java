package pages;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.List;

public class ProductDetailPage extends BasePage {
    public ProductDetailPage(WebDriver driver, WebDriverWait wait){super (driver,wait);}

    String productDetailUrl = "https://www.gittigidiyor.com/taki-saat/aso-6-desi_pdp_";
    public static final List<String> productIds = new ArrayList<>();

    public void goProduct(String productId) throws InterruptedException {

        driver.get(productDetailUrl + productId);
    }

    public void addBasket() throws InterruptedException {

        driver.findElement(By.id("add-to-basket")).click();
        Thread.sleep(2000);

    }

    public void addBasketWithOneVariantProduct(String id, String varyantId) throws InterruptedException {

        downScroll();
        driver.findElement(By.xpath("//*[@id=\"sp-specOptionValue-"+varyantId+"\"]")).click();
        driver.findElement(By.id("add-to-basket")).click();
        Thread.sleep(2000);

    }
    public void addBasketWithTwoVariantProduct(String varyantId, String varyantId2) throws InterruptedException {

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"sp-specOptionValue-632849\"]")));
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@id=\"sp-specOptionValue-"+varyantId+"\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"sp-specOptionValue-"+varyantId2+"\"]")).click();


        driver.findElement(By.id("add-to-basket")).click();
        Thread.sleep(2000);

    }
    public void getProductIds() throws InterruptedException {

        downScroll();
        Thread.sleep(1000);
        productIds.add(driver.findElement(By.id("DescriptionTabProductId")).getText());
    }

    public void checkCargoModels(String cargoModel){

        if (cargoModel.equals("Aynı Gün Teslimat Seçeneği")) {
            Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"same-day-delivery\"]/span")).getText(), cargoModel);
        } else {
            Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"sp-shipping-text\"]/span[1]")).getText(), cargoModel);
        }

    }

    public void clickShoppingNowButton() throws InterruptedException {

        driver.findElement(By.id("buy-now")).click();
        Thread.sleep(2000);
    }

}
