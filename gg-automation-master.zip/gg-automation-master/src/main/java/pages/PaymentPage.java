package pages;

import entities.GittigidiyorDatabases;
import entities.PaymentDatabases;
import model.DiscountPromo;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotSelectableException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class PaymentPage extends BasketPage {
    public PaymentPage(WebDriver driver, WebDriverWait wait) throws InterruptedException, SQLException, ClassNotFoundException
    {super (driver,wait);}

    PaymentDatabases paymentDB = new PaymentDatabases(driver,wait);
    GittigidiyorDatabases ggDB = new GittigidiyorDatabases(driver,wait);
    public static String discountInPayment;
    public static String cargoModel;
    public static String paidAmount;


    public void selectOtherCardTab () throws InterruptedException {

        wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Farklı Kart Kullan")));
        Thread.sleep(2000);
        driver.findElement(By.linkText("Farklı Kart Kullan")).click();

    }

    public void enterCreditCard (String cardNo) throws InterruptedException {

        wait.until(ExpectedConditions.elementToBeClickable(By.id("CcNumber")));
        WebElement ccNo = driver.findElement(By.id("CcNumber"));
        //CcNumber
        //P-CCNumberField
        ccNo.clear();
        ccNo.sendKeys(cardNo);
        Thread.sleep(1000);

        if (ccNo.getAttribute("value").replace("_", "").replace(" ", "").length() < 16) {
            ccNo.clear();
            ccNo.sendKeys(cardNo);
        }
        driver.findElement(By.id("CcOwner")).sendKeys("test test");
        //P-CCOwnerName
        driver.findElement(By.id("CvvCode")).sendKeys("000");
        //P-CVCNumberField
        downScroll();
        Select Cmounth = new Select(driver.findElement(By.id("CcMonth")));
        //P-CCMonthSelect
        Cmounth.selectByIndex(12);
        Select Cyear = new Select(driver.findElement(By.id("CcYear")));
        //P-CCYearSelect
        Cyear.selectByValue("21");
        Thread.sleep(1000);
        cargoModel = driver.findElement(By.xpath("//div[@id='shopping-total-info']/div[3]/div[3]/div/ul/li[2]/div[2]")).getText();
    }

    public void checkThreeDCheckbox(){
        driver.findElement(By.xpath("//div[@id='CreditCard']/div[5]/div/table/tbody/tr/td/label")).click();
    }

    public void enterThreeDPassword() throws InterruptedException {

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='password']")));
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@name='password']")).sendKeys("a");
        driver.findElement(By.id("submitbutton")).click();
    }

    public void selectDiscountInPayment(String discountID) throws InterruptedException {

        wait.until(ExpectedConditions.elementToBeClickable(By.id("BuyProduct")));
        Select discount = new Select(driver.findElement(By.xpath("//select[@name='Discount']")));
        discount.selectByValue(discountID);
        discountInPayment = driver.findElement(By.xpath("//div[@id='shopping-total-info']/div[3]/div[3]/div/ul/li[3]/div[2]")).getText().replace(" TL", "").replace("-", "").replace(".", "").replace(",", "");

    }

    public void checkContract() throws InterruptedException {

        driver.findElement(By.cssSelector(".mobile-padding td:nth-child(1) > label")).click();
        Thread.sleep(2000);

    }

    public void buyProduct() throws InterruptedException {

        driver.findElement(By.id("BuyProduct")).click();

    }

    public void checkProductPriceInPayment() throws InterruptedException, SQLException, ClassNotFoundException {
       //ProductDetailPage deki getProductIDs çalışmış olmalı.
        String price;
        Integer subTotal = 0;
        String totalPrice = null;
        List<String> productIds = ProductDetailPage.productIds;

        for ( String basketId : ggDB.getBasketID("1008621353")){

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='"+basketId+"']/div")));
            price = driver.findElement(By.xpath("//div[@id='"+basketId+"']/div")).getText().replace(" TL", "").replace(".", "").replace(",", "");
            subTotal = Integer.valueOf(price) + subTotal;

        }

        totalPrice = String.valueOf(subTotal + " TL");
        String productTotalPrice = driver.findElement(By.xpath("//div[@id='shopping-total-info']/div[3]/div[3]/div/div/ul/li/div[2]")).getText().replace(".", "").replace(",", "");
        Assert.assertEquals(productTotalPrice, totalPrice);

    }

    public void checkDiscountInPayment(String discountId) throws InterruptedException, SQLException, ClassNotFoundException {

        DiscountPromo discountPromo;
        String productTotalPrice;
        String calculatedDiscount;
        String percent;
        BigDecimal bigCalculatedDiscount;

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("BuyProduct")));
        discountPromo = ggDB.discountPromoDB(discountId);
        if(driver.findElement(By.xpath("//div[@id='shopping-total-info']/div[3]/div[3]/div/ul/li[3]/div[2]")).isDisplayed()) {
            if (Double.valueOf(discountPromo.getPromoPrice()) > 0) {
                Assert.assertEquals(discountInPayment, discountPromo.getPromoPrice().replace(".", "").replace(",", ""));
            }
            else if(Double.valueOf(discountPromo.getPromoPercent()) > 0){
                productTotalPrice =   driver.findElement(By.xpath("//div[@id='shopping-total-info']/div[3]/div[3]/div/ul/li/div[2]")).getText().replace(",","").replace(".","").replace(" TL", "");
                percent =  discountPromo.getPromoPercent();
                BigDecimal bigProductTotalPrice = new BigDecimal(productTotalPrice);
                BigDecimal bigPercent = new BigDecimal(percent);
                bigCalculatedDiscount = bigProductTotalPrice.multiply(bigPercent).divide(BigDecimal.valueOf(100));
                calculatedDiscount = String.valueOf(bigCalculatedDiscount);
                calculatedDiscount = calculatedDiscount.substring(0,calculatedDiscount.length()-3);
                Assert.assertEquals(discountInPayment, calculatedDiscount);

            }
        }
        else{
            Assert.fail("İndirim alanı gelmiyor.");
        }
    }

    public void checkcargomodelInPaymentShoppingSummary(String cargoDetail) throws InterruptedException, SQLException, ClassNotFoundException {
        String cargoDetailInPaymentShoppngSummary = "";
        for (String basketId : ggDB.getBasketID("1008621353")) {
            if (cargoDetail.equals("Ücretsiz")) {
                cargoDetailInPaymentShoppngSummary = driver.findElement(By.xpath("//div[@id=" + basketId + "]/span/span")).getText().replace(" - Aynı Gün Kargo\n" + "(10:00 öncesi siparişler için)","");
            }
            if (cargoDetail.equals("Aynı Gün Teslimat") || cargoDetail.equals("Alıcı Sepette Öder")) {
                cargoDetailInPaymentShoppngSummary = driver.findElement(By.xpath("//div[@id='" + basketId + "']/span[2]")).getText();
            }
            if (cargoDetail.equals("Alıcı Kapıda Öder")) {
                cargoDetailInPaymentShoppngSummary = driver.findElement(By.xpath("//div[@id=\" + basketId + \"]/span")).getText();
            }
            Assert.assertEquals(cargoDetailInPaymentShoppngSummary, cargoDetail);
        }
    }

    public void checkASOCargoModelInPaymentShoppingSummary(String productId, String cargoDetail) {
        String ASOCargoDetailInPaymentShoppingSummary = driver.findElement(By.xpath("//*[@id=\"" + productId + "-0\"]/div[2]/span[2]")).getText();
        Assert.assertEquals(ASOCargoDetailInPaymentShoppingSummary, cargoDetail);
    }

    public void checkCargoModelInPayment(String expectedCargoModel) throws InterruptedException {

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='shopping-total-info']/div[3]/div[3]/div/div/ul/li[2]/div[2]")));
        Thread.sleep(1500);
        cargoModel = driver.findElement(By.xpath("//div[@id='shopping-total-info']/div[3]/div[3]/div/div/ul/li[2]/div[2]")).getText();
        Assert.assertEquals(expectedCargoModel,cargoModel);
    }

    public void checkPreInfoContractCargoModel(String expectedCargoModel) throws InterruptedException {

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"payment-options-info\"]/div/div/div[2]/div/table/tbody/tr/td[2]/label/a[1]")));
        driver.findElement(By.xpath("//*[@id=\"payment-options-info\"]/div/div/div[2]/div/table/tbody/tr/td[2]/label/a[1]")).click();
        Thread.sleep(1000);
        String cargoModel = driver.findElement(By.xpath("//*[@id=\"mss_main\"]/div[2]/div/table/tbody/tr[3]/td/div/div[25]")).getText();
        Assert.assertEquals(cargoModel, expectedCargoModel);
        driver.findElement(By.xpath("//*[@id=\"modal-container-closer\"]/i")).click();
    }
        public void checkSaleContractCargoModel(String expectedCargoModel) throws InterruptedException {
     

        Thread.sleep(1000);
        driver.findElement(By.xpath("//*[@id=\"payment-options-info\"]/div/div/div[2]/div/table/tbody/tr/td[2]/label/a[2]")).click();
        Thread.sleep(1000);
        String cargoModel = driver.findElement(By.xpath("//*[@id=\"mss_main\"]/div[2]/div/table/tbody/tr[3]/td/div/div[41]")).getText();
        Assert.assertEquals(cargoModel, expectedCargoModel);
        driver.findElement(By.xpath("//*[@id=\"modal-container-closer\"]/i")).click();

    }

    public void getPayAmount(){
        if(driver.findElement(By.xpath("//div[@id='shopping-total-info']/div[3]/div[3]/div/ul/li[3]/div[2]")).isDisplayed()) {
            paidAmount = driver.findElement(By.xpath("//div[@id='shopping-total-info']/div[3]/p[2]/strong/span[2]")).getText().replace(",", "").replace(".", "");
        }
        else{
            paidAmount = driver.findElement(By.xpath("//div[@id='shopping-total-info']/div[3]/p[2]/span")).getText().replace(",", "").replace(".", "");
        }
    }

    public void selectInstallment(){
        driver.findElement(By.xpath("//label[contains(.,'6 Taksit')]")).click();
    }
}
