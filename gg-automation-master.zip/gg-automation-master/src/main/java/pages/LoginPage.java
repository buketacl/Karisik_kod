package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage extends BasePage {
    public LoginPage(WebDriver driver, WebDriverWait wait){super (driver,wait);}


    public void login(String userName, String password) throws InterruptedException {

        driver.get(baseUrl+"/uye-girisi?url=%2F");
        driver.findElement(By.id("L-UserNameField")).sendKeys(userName);
        driver.findElement(By.id("L-PasswordField")).sendKeys(password);
        Thread.sleep(1000);
        driver.findElement(By.id("gg-login-enter")).click();
    }
}
