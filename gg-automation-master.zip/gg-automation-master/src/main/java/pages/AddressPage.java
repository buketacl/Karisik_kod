package pages;

import entities.GittigidiyorDatabases;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AddressPage extends BasePage {
    public AddressPage(WebDriver driver, WebDriverWait wait) throws InterruptedException, SQLException, ClassNotFoundException {super (driver,wait);}
    public static String discountInAddress;
    public static final List<String> addressIds = new ArrayList<>();
    GittigidiyorDatabases ggDB = new GittigidiyorDatabases(driver,wait);

    public void getAddressIds() throws InterruptedException {

        downScroll();
        Thread.sleep(1000);
        addressIds.add(driver.findElement(By.id("data-id")).getText());
    }

    public void continuePayment() {

        wait.until(ExpectedConditions.elementToBeClickable(By.id("post-address-form")));
        driver.findElement(By.id("post-address-form")).click();
    }

    public void addNewAddress(String tittle, String name, String surname, String cityId, String countyId, String neighborhoodId, String zipCode, String address, String phoneNumber) throws InterruptedException {

        driver.findElement(By.xpath("//a[@id='AddNew']")).click();
        driver.findElement(By.xpath("//input[@name='title']")).sendKeys(tittle);
        driver.findElement(By.xpath("//input[@name='name']")).sendKeys(name);
        driver.findElement(By.xpath("//input[@name='surname']")).sendKeys(surname);
        Select city = new Select(driver.findElement(By.xpath("//select[@name='cityId']")));
        city.selectByValue(cityId);
        Thread.sleep(1000);
        Select county = new Select(driver.findElement(By.xpath("(//select[@name='countyId'])[2]")));
        county.selectByValue(countyId);
        Thread.sleep(1000);
        Select neighborhood = new Select(driver.findElement(By.xpath("(//select[@name='neighborhoodId'])[2]")));
        neighborhood.selectByValue(neighborhoodId);
        driver.findElement(By.xpath("//input[@name='zipCode']")).sendKeys(zipCode);
        driver.findElement(By.xpath("//textarea[@name='address']")).sendKeys(address);
        driver.findElement(By.xpath("//input[@name='phone-number']")).sendKeys(phoneNumber);
        driver.findElement(By.xpath("//input[@value='Kaydet ve Devam Et']")).click();


    }

    public void editAddress(String editTittle, String editName, String editSurname, String editCityId, String editCountyId, String editNeighborhoodId, String editZipCode, String editAddress, String editPhoneNumber) throws InterruptedException, SQLException, ClassNotFoundException {

        String addressId = driver.findElement(By.xpath("//div[3]/ul/li")).getAttribute("id").replace("item-", "");
        driver.findElement(By.xpath("//li[@id='item-" + addressId + "']/div/div[4]/a/span/i")).click();


        driver.findElement(By.xpath("//input[@name='title']")).clear();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@name='title']")).sendKeys(editTittle);

        driver.findElement(By.xpath("//input[@name='name']")).clear();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@name='name']")).sendKeys(editName);

        driver.findElement(By.xpath("//input[@name='surname']")).clear();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@name='surname']")).sendKeys(editSurname);

        Thread.sleep(1000);
        Select city = new Select(driver.findElement(By.xpath("//select[@name='cityId']")));
        city.selectByValue(editCityId);
        Thread.sleep(1000);
        Select county = new Select(driver.findElement(By.xpath("(//select[@name='countyId'])[2]")));
        county.selectByValue(editCountyId);
        Thread.sleep(1000);
        Select neighborhood = new Select(driver.findElement(By.xpath("(//select[@name='neighborhoodId'])[2]")));
        neighborhood.selectByValue(editNeighborhoodId);

        driver.findElement(By.xpath("//input[@name='zipCode']")).clear();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@name='zipCode']")).sendKeys(editZipCode);

        driver.findElement(By.xpath("//textarea[@name='address']")).clear();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//textarea[@name='address']")).sendKeys(editAddress);

        driver.findElement(By.xpath("//input[@name='phone-number']")).clear();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@name='phone-number']")).sendKeys(editPhoneNumber);

        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@value='Kaydet ve Devam Et']")).click();

    }

    public void selectAgt(String adressID) throws InterruptedException {

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@id='item-" + adressID +"']/div/div[3]/p/strong")));
        Thread.sleep(1000);
        driver.findElement(By.xpath("//li[@id='item-" + adressID +"']/div/div[3]/p/strong")).click();
        Thread.sleep(1000);
        WebElement adressAGT = driver.findElement(By.xpath("//div[@id='product-shipping-box']/div[2]/label"));
        wait.until(ExpectedConditions.elementToBeClickable(adressAGT));
        if (!adressAGT.isSelected()) {
            driver.findElement(By.xpath("//div[@id='product-shipping-box']/div[2]/label")).click();
        }
        Thread.sleep(1000);
    }

    public void unselectAgt(String adressID) {
        driver.findElement(By.xpath("//*[@id=\"item-" + adressID + "\"]/div[1]/div[3]")).click();
        if (driver.findElement(By.xpath(".same-day-delivery-checkbox")).isSelected()) {//
            driver.findElement(By.xpath("//*[@id=\"same-day-delivery-checkbox-" + adressID + "0\"]")).click();
        }
    }

    public void checkcargomodelInAddress(String cargoDetail) {

        String cargoDetailInAddress = driver.findElement(By.xpath("//*[@id=\"total-price-summary-container\"]/div/div[4]/div/div/ul/li[2]/div[2]")).getText();
        Assert.assertEquals(cargoDetailInAddress, cargoDetail);

    }

    public void checkproductpriceInAddress(String productPrice) {

        String productPriceInAddress = driver.findElement(By.xpath("//div[@id='total-price-summary-container']/div/div[4]/div/div/ul/li/div[2]")).getText().replace(" TL", "").replace(".", "").replace(",", "");
        Assert.assertEquals(productPriceInAddress, productPrice);
    }

    public void totalProductPriceInAddress(String totalPrice) {
        String totalPriceInAddress = driver.findElement(By.xpath("//div[@id='total-price-summary-container']/div/div[5]/div[2]/p")).getText().replace(" TL", "").replace(".", "").replace(",", "");
        Assert.assertEquals(totalPriceInAddress, totalPrice);
    }

    public void checkDiscountInAddress() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='total-price-summary-container']/div/div[4]/div/div/ul/li[3]/div[2]")));
        discountInAddress = driver.findElement(By.xpath("//div[@id='total-price-summary-container']/div/div[4]/div/div/ul/li[3]/div[2]")).getText().replace(" TL", "").replace("-", "").replace(".", "").replace(",", "");
        Assert.assertEquals(discountInAddress, BasketPage.discountInBasket);
    }

    public void checkTotalNumberOfProductInAddress(String totalNumberOfProduct){
        String numberOfProduct = driver.findElement(By.xpath("//div[4]/div/div/ul/li/div")).getText();
        Assert.assertEquals(totalNumberOfProduct, numberOfProduct);
    }

    public void guestUserInfo(String eposta, String phoneNumber, String name, String surname, String cityId, String countyId, String neighborhoodId, String zipCode, String address, String secondPersonInfo) throws InterruptedException {

        driver.findElement(By.xpath("//*[@id=\"UEmail\"]")).sendKeys(eposta);
        driver.findElement(By.xpath("//*[@id=\"guest-address-form\"]/div[3]/div/div[2]/input[1]")).sendKeys(phoneNumber);
        driver.findElement(By.xpath("//*[@id=\"guest-address-form\"]/div[5]/div/div[2]/input")).sendKeys(name);
        driver.findElement(By.xpath("//*[@id=\"guest-address-form\"]/div[6]/div/div[2]/input")).sendKeys(surname);
        Select city = new Select(driver.findElement(By.xpath("//*[@id=\"guest-address-form\"]/div[7]/div/div[2]/select")));
        city.selectByValue(cityId);
        Thread.sleep(1000);
        Select county = new Select(driver.findElement(By.xpath("//*[@id=\"guest-address-form\"]/div[8]/div/div[2]/select")));
        county.selectByValue(countyId);
        Thread.sleep(1000);
        Select neighborhood = new Select(driver.findElement(By.xpath("//*[@id=\"guest-address-form\"]/div[9]/div/div[2]/select")));
        neighborhood.selectByValue(neighborhoodId);
        driver.findElement(By.xpath("//*[@id=\"guest-address-form\"]/div[10]/div/div[2]/textarea")).sendKeys(address);
        driver.findElement(By.xpath("//*[@id=\"guest-address-form\"]/div[11]/div/div[2]/input")).sendKeys(zipCode);
        driver.findElement(By.xpath("//*[@id=\"guest-phone-info-container\"]/div/div[2]/input[1]")).sendKeys(secondPersonInfo);
        driver.findElement(By.xpath("//*[@id=\"post-address-form\"]")).click();
    }

}
