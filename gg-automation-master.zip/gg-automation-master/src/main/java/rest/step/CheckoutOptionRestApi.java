package rest.step;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class CheckoutOptionRestApi {

    public String createJsonFileWithArrayForSave (String criteriaField, String value, String values){

        JSONObject jsonObject = new JSONObject();
        JSONArray criterias = new JSONArray();
        JSONObject criteria = new JSONObject();
        criteria.put("criteria", criteriaField);
        criteria.put("value", value);
        criteria.put("values", values);
        criterias.add(criteria);
        jsonObject.put("criteria", criterias);
        String request = jsonObject.toJSONString();
        return request;
    }
    public String createJsonFileForDelete (String criteriaField){

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("criteria", criteriaField);
        String request = jsonObject.toJSONString();
        return request;
    }

    public String createJsonFileForUpdate (String criteriaField, String value, String values){

        JSONObject mainJsonObject = new JSONObject();
        JSONObject criteria = new JSONObject();
        criteria.put("criteria", criteriaField);
        criteria.put("value", value);
        criteria.put("values", values);
        mainJsonObject.put("criteria", criteria);
        String request = mainJsonObject.toJSONString();
        return request;
    }
}
