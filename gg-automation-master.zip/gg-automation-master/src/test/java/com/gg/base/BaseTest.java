package com.gg.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BaseTest {
    private static WebDriver driver;
    private static WebDriverWait wait;

    public void setup() {
        driver = new FirefoxDriver();
        wait = new WebDriverWait(driver, 35);

    }


    public WebDriver getDriver() {
        return driver;
    }

    public WebDriverWait getWait() {
        return wait;
    }
}
