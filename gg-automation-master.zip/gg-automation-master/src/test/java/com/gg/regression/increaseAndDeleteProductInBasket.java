package com.gg.regression;

import com.gg.base.BaseTest;
import com.thoughtworks.gauge.Step;
import pages.BasePage;
import pages.BasketPage;
import pages.LoginPage;
import pages.ProductDetailPage;

import java.sql.SQLException;

public class increaseAndDeleteProductInBasket extends BaseTest {


    public increaseAndDeleteProductInBasket() throws InterruptedException, SQLException, ClassNotFoundException {
    }


    @Step("Browser open")
    public void browserOpen() {

        BasePage basepage = new BasePage(getDriver(), getWait());
        basepage.openBrowser();
    }

    @Step("Login <username1> <password>")
    public void Login(String username, String password) throws InterruptedException {
        LoginPage loginPage = new LoginPage(getDriver(), getWait());
        loginPage.login(username, password);
    }

    @Step("Go to product <productID> and add basket")
    public void goToProduct(String productId) throws InterruptedException, SQLException, ClassNotFoundException {
        ProductDetailPage pdp = new ProductDetailPage(getDriver(), getWait());
        BasketPage basketPage = new BasketPage(getDriver(), getWait());
        pdp.goProduct(productId);
        pdp.getProductIds();
        pdp.addBasket();
        basketPage.goToBasket();
    }

    @Step("Delete product")
    public void deleteProduct() throws InterruptedException, SQLException, ClassNotFoundException {
        BasketPage basketPage = new BasketPage(getDriver(), getWait());
        basketPage.deleteItem();
    }

    @Step("Check if the basket is empty")
    public void checkIfTheBasketIsEmpty() throws InterruptedException, SQLException, ClassNotFoundException {
        BasketPage basketPage = new BasketPage(getDriver(), getWait());
        basketPage.checkIsBasketEmpty();

    }

    @Step("Quit the browser")
    public void quitTheBrowser() {
        getDriver().quit();

    }

    @Step("Increase product <count>")
    public void increaseProduct(String count) throws InterruptedException, SQLException, ClassNotFoundException {
        BasketPage basketPage = new BasketPage(getDriver(), getWait());
        basketPage.increaseProduct(count);

    }

    @Step("Check product count <productCount>")
    public void checkProductCount(String productCount) throws InterruptedException, SQLException, ClassNotFoundException {
        Thread.sleep(1500);
        BasketPage basketPage = new BasketPage(getDriver(), getWait());
        basketPage.checkTotalNumberOfProductInBasket(productCount);

    }
}







