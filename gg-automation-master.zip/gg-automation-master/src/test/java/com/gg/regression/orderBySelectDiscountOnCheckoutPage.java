package com.gg.regression;

import com.gg.base.BaseTest;
import com.thoughtworks.gauge.Step;
import com.thoughtworks.gauge.Table;
import pages.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class orderBySelectDiscountOnCheckoutPage extends BaseTest {

    public orderBySelectDiscountOnCheckoutPage() throws InterruptedException, SQLException, ClassNotFoundException {
    }


    @Step("Open the browser")
    public void openBrowser() {
        setup();
        BasePage basePage = new BasePage(getDriver(), getWait());
        basePage.openBrowser();
    }

    @Step("Success login with <username> <password>")
    public void login(String username, String password) throws InterruptedException {
        LoginPage loginPage = new LoginPage(getDriver(), getWait());
        loginPage.login(username, password);
    }

    @Step("Go to product <id>")
    public void goProduct(String id) throws InterruptedException {
        ProductDetailPage pdp = new ProductDetailPage(getDriver(), getWait());
        pdp.goProduct(id);
    }

    @Step("Check cargo model <cargoModel>")
    public void checkCargoModel(String cargoModel) throws InterruptedException {
        ProductDetailPage pdp = new ProductDetailPage(getDriver(), getWait());
        pdp.checkCargoModels(cargoModel);

    }

    @Step("Add basket")
    public void addBasket() throws InterruptedException {
        ProductDetailPage pdp = new ProductDetailPage(getDriver(), getWait());
        pdp.getProductIds();
        pdp.addBasket();
    }

    @Step("Go to the basket")
    public void goToBasket() throws InterruptedException, SQLException, ClassNotFoundException {
        BasketPage basketPage = new BasketPage(getDriver(), getWait());
        basketPage.goToBasket();
    }

    @Step("Check the product price at basket")
    public void checkProductPriceAtBasket() throws InterruptedException, SQLException, ClassNotFoundException {
        BasketPage basketPage = new BasketPage(getDriver(), getWait());
        basketPage.checkProductPrice();
    }

    @Step("Check total number of product at basket <numberOfProduct>")
    public void checkTotalNumberOfProductAtBasket(String numberOfProduct) throws InterruptedException, SQLException, ClassNotFoundException {
        BasketPage basketPage = new BasketPage(getDriver(), getWait());
        basketPage.checkTotalNumberOfProductInBasket(numberOfProduct);
    }

    @Step("Check cargo model at basket <cargoModel>")
    public void checkCargoModelAtBasket(String cargoModel) throws InterruptedException, SQLException, ClassNotFoundException {
        BasketPage basketPage = new BasketPage(getDriver(), getWait());
        basketPage.checkCargoModelAtBasket(cargoModel);
    }

    @Step("Go to address")
    public void goToAddress() throws InterruptedException, SQLException, ClassNotFoundException {
        BasketPage basketPage = new BasketPage(getDriver(), getWait());
        basketPage.goToAddress();
    }

    @Step("Check product price in address <productPrice>")
    public void checkProductPriceInAddress(String productPrice) throws InterruptedException, SQLException, ClassNotFoundException {
        AddressPage addressPage = new AddressPage(getDriver(), getWait());
        addressPage.checkproductpriceInAddress(productPrice);
    }

    @Step("Check cargo model in address <cargoModel>")
    public void checkCargoModelInAddress(String cargoModel) throws InterruptedException, SQLException, ClassNotFoundException {
        AddressPage addressPage = new AddressPage(getDriver(), getWait());
        addressPage.checkcargomodelInAddress(cargoModel);
    }

    @Step("Check total product price in address <totalPrice>")
    public void checkTotalProductPriceInAddress(String totalPrice) throws InterruptedException, SQLException, ClassNotFoundException {
        AddressPage addressPage = new AddressPage(getDriver(), getWait());
        addressPage.totalProductPriceInAddress(totalPrice);
    }

    @Step("Check total number of product in address <numberOfProduct>")
    public void checkTotalNumberOfProductInAddress(String numberOfProduct) throws InterruptedException, SQLException, ClassNotFoundException {
        AddressPage addressPage = new AddressPage(getDriver(), getWait());
        addressPage.checkTotalNumberOfProductInAddress(numberOfProduct);
    }

    @Step("Continue payment in address")
    public void continuePaymentInAddress() throws InterruptedException, SQLException, ClassNotFoundException {
        AddressPage addressPage = new AddressPage(getDriver(), getWait());
        addressPage.continuePayment();
    }

    @Step("Check cargo model in payment <cargoModel>")
    public void checkCargoModelInPayment(String cargoModel) throws InterruptedException, SQLException, ClassNotFoundException {
        PaymentPage paymentPage = new PaymentPage(getDriver(), getWait());
        paymentPage.checkCargoModelInPayment(cargoModel);
    }

    @Step("Check product price in payment")
    public void checkProductPriceInPayment() throws InterruptedException, SQLException, ClassNotFoundException {
        PaymentPage paymentPage = new PaymentPage(getDriver(), getWait());
        paymentPage.checkProductPriceInPayment();
    }

    @Step("Check cargo model in payment success <id> <cargoModel>")
    public void checkCargoModelInPaymentSuccess(String id, String cargoModel) {
        PaymentSuccessPage paymentSuccessPage = new PaymentSuccessPage(getDriver(), getWait());
        paymentSuccessPage.checkCargoModelInPaymentSuccess(id, cargoModel);
        paymentSuccessPage.getSaleCode(id);
    }

    @Step("Check discount in payment success")
    public void checkDiscountInPaymentSuccess() {
        PaymentSuccessPage paymentSuccessPage = new PaymentSuccessPage(getDriver(), getWait());
        paymentSuccessPage.checkDiscountInPaymentSuccess();
        paymentSuccessPage.getTotalPrice();
    }

    @Step("Go to products <table>")
    public void goToProducts(Table table) throws InterruptedException {
        ProductDetailPage pdp = new ProductDetailPage(getDriver(), getWait());
        List<String> rows = new ArrayList<>();
        for (int i = 0; i < table.getRows().size(); i++) {
            rows = table.getRows().get(i);
            pdp.goProduct(rows.get(0));
            pdp.checkCargoModels(rows.get(1));
            pdp.getProductIds();
            pdp.addBasket();
            rows.clear();
        }


    }

    @Step("Go to first product and check cargo model and add basket <productId> <cargoModel>")
    public void goFirstProductAndCheckCargoModel(String productId, String cargoModel) throws InterruptedException {
        ProductDetailPage pdp = new ProductDetailPage(getDriver(), getWait());
        pdp.goProduct(productId);
        pdp.checkCargoModels(cargoModel);
        pdp.getProductIds();
        pdp.addBasket();
    }

    @Step("Go to second product and check cargo model and add basket <productId> <cargoModel>")
    public void goSecondProductAndCheckCargoModel(String productId, String cargoModel) throws InterruptedException {
        ProductDetailPage pdp = new ProductDetailPage(getDriver(), getWait());
        pdp.goProduct(productId);
        pdp.checkCargoModels(cargoModel);
        pdp.getProductIds();
        pdp.addBasket();
    }

    @Step("Check of products cargo model in payment success <id1> <id2> <cargoModel>")
    public void checkOfProductsCargoModelAndDiscountInPaymentSuccess(String id1, String id2, String cargoModel) {
        PaymentSuccessPage paymentSuccessPage = new PaymentSuccessPage(getDriver(), getWait());
        paymentSuccessPage.checkCargoModelInPaymentSuccess(id1, cargoModel);
        paymentSuccessPage.checkCargoModelInPaymentSuccess(id2, cargoModel);
        paymentSuccessPage.getSaleCode(id1);
        paymentSuccessPage.getSaleCode(id2);

    }

    @Step("Select AGT in address <addressId>")
    public void selectAGT(String addressId) throws InterruptedException, SQLException, ClassNotFoundException {
        AddressPage addressPage = new AddressPage(getDriver(), getWait());
        addressPage.selectAgt(addressId);

    }

    @Step("Check product price after choosing AGT <productPrice>")
    public void checkProductPriceAfterAGTInAddress(String productPrice) throws InterruptedException, SQLException, ClassNotFoundException {
        AddressPage addressPage = new AddressPage(getDriver(), getWait());
        addressPage.checkproductpriceInAddress(productPrice);
    }

    @Step("Check cargo model after choosing AGT <cargoModel>")
    public void checkCargoModelAfterAGTInAddress(String cargoModel) throws InterruptedException, SQLException, ClassNotFoundException {
        AddressPage addressPage = new AddressPage(getDriver(), getWait());
        addressPage.checkcargomodelInAddress(cargoModel);
    }

    @Step("Check total product price after choosing AGT <totalPrice>")
    public void checkTotalProductPriceAfterAGTInAddress(String totalPrice) throws InterruptedException, SQLException, ClassNotFoundException {
        AddressPage addressPage = new AddressPage(getDriver(), getWait());
        addressPage.totalProductPriceInAddress(totalPrice);
    }

    @Step("AGT+ASO Check cargo model in payment success <id1> <id2> <cargoModel> <cargoModel2>")
    public void AGTASOCheckCargomodelPaymentSuccess(String id1, String id2, String cargoModel1, String cargoModel2) {
        PaymentSuccessPage paymentSuccessPage = new PaymentSuccessPage(getDriver(), getWait());
        paymentSuccessPage.checkCargoModelInPaymentSuccess(id1, cargoModel1);
        paymentSuccessPage.checkCargoModelInPaymentSuccess(id2, cargoModel2);
        paymentSuccessPage.getSaleCode(id1);
        paymentSuccessPage.getSaleCode(id2);
    }

    @Step("AGT+ASO Check discount in payment success")
    public void AGTASOCheckCargomodelAndDiscountInPaymentSuccess() {
        PaymentSuccessPage paymentSuccessPage = new PaymentSuccessPage(getDriver(), getWait());
        paymentSuccessPage.checkDiscountInPaymentSuccess();
        paymentSuccessPage.getTotalPrice();
    }

    @Step("AGT+ASO Comb Check cargo model in payment success <id1> <id2> <id3> <id4> <cargoModel1> <cargoModel2>")
    public void AGTASOCmbCheckCargoModelInPaymentSuccess(String id1, String id2, String id3, String id4, String cargoModel1, String cargoModel2) {
        PaymentSuccessPage paymentSuccessPage = new PaymentSuccessPage(getDriver(), getWait());
        paymentSuccessPage.checkCargoModelInPaymentSuccess(id1, cargoModel1);
        paymentSuccessPage.checkCargoModelInPaymentSuccess(id2, cargoModel1);
        paymentSuccessPage.checkCargoModelInPaymentSuccess(id3, cargoModel2);
        paymentSuccessPage.checkCargoModelInPaymentSuccess(id4, cargoModel2);
        paymentSuccessPage.getSaleCode(id1);
        paymentSuccessPage.getSaleCode(id2);
        paymentSuccessPage.getSaleCode(id3);
        paymentSuccessPage.getSaleCode(id4);

    }

    @Step("AGT+ASO Comb Check discount in payment success")
    public void AGTASOCmbCheckCargoModelAndDiscountInPaymentSuccess() {
        PaymentSuccessPage paymentSuccessPage = new PaymentSuccessPage(getDriver(), getWait());
        paymentSuccessPage.checkDiscountInPaymentSuccess();
        paymentSuccessPage.getTotalPrice();
    }

    @Step("Enter the credit card <cardNo>")
    public void enterCreditCard(String cardNo) throws InterruptedException, SQLException, ClassNotFoundException {
        PaymentPage paymentPage = new PaymentPage(getDriver(), getWait());
        paymentPage.selectOtherCardTab();
        paymentPage.enterCreditCard(cardNo);
    }

    @Step("Check discount in payment <discountId>")
    public void selectDiscountInPayment(String discountId) throws InterruptedException, SQLException, ClassNotFoundException {
        PaymentPage paymentPage = new PaymentPage(getDriver(), getWait());
        paymentPage.checkDiscountInPayment(discountId);

    }

    @Step("Enter Pos3D password")
    public void enterPos3DPassword() throws InterruptedException, SQLException, ClassNotFoundException {
        PaymentPage paymentPage = new PaymentPage(getDriver(), getWait());
        paymentPage.enterThreeDPassword();
    }


    @Step("Select discount at basket <discountId>")
    public void selectDiscountAtBasket(String discountId) throws InterruptedException, SQLException, ClassNotFoundException {
        BasketPage basketPage = new BasketPage(getDriver(), getWait());
        basketPage.selectDiscountInBasket(discountId);

    }

    @Step("Check discount in basket <discountId>")
    public void checkDiscountInBasket(String discountId) throws InterruptedException, SQLException, ClassNotFoundException {
        BasketPage basketPage = new BasketPage(getDriver(), getWait());
        basketPage.checkDiscountInBasket(discountId);

    }

    @Step("Select discount at payment <discountId>")
    public void selectDiscountAtPaymnet(String discountId) throws InterruptedException, SQLException, ClassNotFoundException {
        PaymentPage paymentPage = new PaymentPage(getDriver(), getWait());
        paymentPage.selectDiscountInPayment(discountId);
    }


    @Step("Buy product")
    public void buyProduct() throws InterruptedException, SQLException, ClassNotFoundException {
        PaymentPage paymentPage = new PaymentPage(getDriver(), getWait());
        paymentPage.checkContract();
        paymentPage.getPayAmount();
        paymentPage.buyProduct();
    }

    @Step("Check paid amount in payment success")
    public void checkPaidAmountAtPaymentSuccess() {
        PaymentSuccessPage paymentSuccessPage = new PaymentSuccessPage(getDriver(), getWait());
        paymentSuccessPage.checkTotalPriceAtPaymentSuccess();
    }

    @Step("AGT+ASO Check paid amount in payment success")
    public void checkASÖAGTProductsPaidAmountAtPaymentSuccess() {
        PaymentSuccessPage paymentSuccessPage = new PaymentSuccessPage(getDriver(), getWait());
        paymentSuccessPage.checkTotalPriceAtPaymentSuccess();
    }

    @Step("AGT+ASO Comb Check paid amount in payment success ")
    public void checkASÖAGTCOMProductsPaidAmountAtPaymentSuccess() {
        PaymentSuccessPage paymentSuccessPage = new PaymentSuccessPage(getDriver(), getWait());
        paymentSuccessPage.checkTotalPriceAtPaymentSuccess();
    }

    @Step("Check of products paid amount in payment success ")
    public void checkComProductsPaidAmountAtPaymentSuccessPage() {
        PaymentSuccessPage paymentSuccessPage = new PaymentSuccessPage(getDriver(), getWait());
        paymentSuccessPage.checkTotalPriceAtPaymentSuccess();
    }

    @Step("Quit browser")
    public void quitBrowser() {
        getDriver().quit();

    }

    @Step("Increase product at basket <count>")
    public void increaseProductAtBasket(String count) throws InterruptedException, SQLException, ClassNotFoundException {
        BasketPage basketPage = new BasketPage(getDriver(), getWait());
        Thread.sleep(1500);
        basketPage.increaseProduct(count);
    }

    @Step("Check the product price after increase at basket")
    public void checkTheProductPriceAfterIncrease() throws InterruptedException, SQLException, ClassNotFoundException {
        BasketPage basketPage = new BasketPage(getDriver(), getWait());
        basketPage.checkProductPrice();

    }

    @Step("Check total number of product after increase at basket <count>")
    public void checkTotalNumberOfProductAfterIncrease(String count) throws InterruptedException, SQLException, ClassNotFoundException {
        BasketPage basketPage = new BasketPage(getDriver(), getWait());
        basketPage.checkTotalNumberOfProductInBasket(count);
    }

    @Step("Check cargo model after increase at basket <cargoModel>")
    public void checkCargoModelAfterIncrease(String cargoModel) throws InterruptedException, SQLException, ClassNotFoundException {
        BasketPage basketPage = new BasketPage(getDriver(), getWait());
        basketPage.checkCargoModelAtBasket(cargoModel);
    }

    @Step("Decrease product at basket <count>")
    public void decreaseProductAtBasket(String count) throws InterruptedException, SQLException, ClassNotFoundException {
        BasketPage basketPage = new BasketPage(getDriver(), getWait());
        basketPage.increaseProduct(count);
    }

    @Step("Click shopping now")
    public void clickShoppingNow() throws InterruptedException {
        ProductDetailPage pdp = new ProductDetailPage(getDriver(), getWait());
        pdp.getProductIds();
        pdp.clickShoppingNowButton();
    }

    @Step("Check contract in payment payment <expectedCargoModel>")
    public void checkContract(String expectedCargoModel) throws InterruptedException, SQLException, ClassNotFoundException {
        PaymentPage paymentPage = new PaymentPage(getDriver(), getWait());
        paymentPage.checkPreInfoContractCargoModel(expectedCargoModel);
        paymentPage.checkSaleContractCargoModel(expectedCargoModel);
    }

    //*****************************************
    //Adres Stepleri

    @Step("Add new address <tittle> <cityId> <countyId> <neighborhoodId> <zipCode> <address> <phoneNumber>")
    public void addNewAddress(String tittle, String cityId, String countyId, String neighborhoodId, String zipCode, String address, String phoneNumber) throws InterruptedException, SQLException, ClassNotFoundException {
        AddressPage addressPage = new AddressPage(getDriver(), getWait());
        addressPage.addNewAddress(tittle, "Murat", "Tuccar", cityId, countyId, neighborhoodId, zipCode, address, phoneNumber);
    }

    @Step("Edit address <tittle> <cityId> <countyId> <neighborhoodId> <zipCode> <address> <phoneNumber>")
    public void editAddress(String editTittle, String editCityId, String editCountyId, String editNeighborhoodId, String editZipCode, String editAddress, String editPhoneNumber) throws InterruptedException, SQLException, ClassNotFoundException {
        AddressPage addressPage = new AddressPage(getDriver(), getWait());
        addressPage.editAddress(editTittle, "Murat", "Tuccar", editCityId, editCountyId, editNeighborhoodId, editZipCode, editAddress, editPhoneNumber);
    }


    @Step("Check cargo model in shopping summary at payment <cargoModel>")
    public void checkCargoModelShoppingSummary(String cargoModel) throws InterruptedException, SQLException, ClassNotFoundException {
        PaymentPage paymentPage = new PaymentPage(getDriver(), getWait());
        paymentPage.checkcargomodelInPaymentShoppingSummary(cargoModel);

    }
}













