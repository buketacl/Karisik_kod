package com.gg.payment.channels;

import com.thoughtworks.gauge.Step;
import com.thoughtworks.gauge.Table;
import entities.PaymentDatabases;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.*;

import java.sql.SQLException;
import java.util.List;

public class PosNon3D {

    WebDriver driver = new FirefoxDriver();
    WebDriverWait wait = new WebDriverWait(driver, 35);

    ProductDetailPage productDetailPage = new ProductDetailPage(driver, wait);
    PaymentPage paymentPage = new PaymentPage(driver, wait);
    BasePage basePage = new BasePage(driver, wait);
    LoginPage loginPage = new LoginPage(driver, wait);
    BasketPage basketPage = new BasketPage(driver, wait);
    AddressPage addressPage = new AddressPage(driver, wait);
    PaymentDatabases paymentDB = new PaymentDatabases(driver, wait);
    PaymentSuccessPage successPage = new PaymentSuccessPage(driver, wait);

    public PosNon3D() throws InterruptedException, SQLException, ClassNotFoundException {
    }


    @Step("Open Browser")
    public void openBrowser() {

        // System.setProperty("webdriver.chrome.driver", "chromedriver");

        basePage.openBrowser();
    }

    @Step("Login with <finartz11> and <gittigidiyor123>")
    public void login(String username, String password) throws InterruptedException {


        loginPage.login(username, password);

    }

    @Step("Add to basket <table>")
    public void addToBasket(Table table) throws InterruptedException {


        for (int i = 0; i < table.getRows().size(); i++) {
            List<String> rows = table.getRows().get(i);

            for (String productId : rows) {
                System.out.println(productId);
                productDetailPage.goProduct(productId);
                productDetailPage.getProductIds();
                productDetailPage.addBasket();
            }
        }

    }

    @Step("Add to basket variant product <productId> with variant id <766080> <632853>")
    public void variantProductAddToBasket(String productId,String variantId,String variantId2) throws InterruptedException {

                System.out.println(productId);
                productDetailPage.goProduct(productId);
                productDetailPage.getProductIds();
                productDetailPage.addBasketWithTwoVariantProduct(variantId, variantId2);



    }

    @Step("User check the basket")
    public void checkBasket() throws InterruptedException, SQLException, ClassNotFoundException {

        basketPage.goToBasket();
        basketPage.goToAddress();
    }

    @Step("User continue the payment page")
    public void checkAddressPage() {

        addressPage.continuePayment();
    }

    @Step("User enter the credit card <4355 0843 5508 4358>")
    public void enterCreditCard(String creditCard) throws InterruptedException, SQLException, ClassNotFoundException {

        paymentPage.selectOtherCardTab();
        paymentPage.enterCreditCard(creditCard);
        paymentPage.checkContract();


    }

    @Step("Browser close")
    public void closeBrowser() {
        basePage.closeBrowser();
    }

    @Step("User see payment success page")
    public void paymentInfo() {
        for(String productId: ProductDetailPage.productIds) {
            successPage.getCount(productId);
            successPage.getSaleCode(productId);
            successPage.getUnitPrice(productId);

        }
        successPage.getTotalPrice();

    }

    @Step("Check databases <channel>")
    public void checkDatebases(String channel) throws InterruptedException, SQLException, ClassNotFoundException {
        paymentDB.checkSatisDB();
        paymentDB.checkSalePaymentItemDB(channel);
        paymentDB.checkPaymentDB(channel);
        paymentDB.checkPaymentLogDB();

    }


    @Step("Select installment")
    public void selectInstallment() {
        paymentPage.selectInstallment();
    }

    @Step("Select discountid <1172>")
    public void selectDiscount(String discountId) throws InterruptedException {
        paymentPage.selectDiscountInPayment(discountId);
    }

    @Step("Buy products")
    public void buyProduct() throws InterruptedException {
        paymentPage.buyProduct();

    }
}
