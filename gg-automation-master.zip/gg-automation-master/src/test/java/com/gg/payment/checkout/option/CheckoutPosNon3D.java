package com.gg.payment.checkout.option;

import com.thoughtworks.gauge.Step;
import rest.step.CheckoutOptionRestApiTest;

public class CheckoutPosNon3D {
    @Step("Create checkout rule set")
    public void createRuleMaxAmount() {

        CheckoutOptionRestApiTest checkoutoption = new CheckoutOptionRestApiTest();
        checkoutoption.updateCriteria("5f743c5e88cd1b0001a31d8d", "MAX_AMOUNT", "1300", "null");

    }


}
