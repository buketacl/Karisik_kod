package rest.step;

import io.qameta.allure.restassured.AllureRestAssured;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.Test;

public class CheckoutOptionRestApiTest {

    @Test
    public void saveCriteria(String id, String criteria, String value , String values) {

        CheckoutOptionRestApi chekoutOptionRestApi = new CheckoutOptionRestApi();

        Response response = RestAssured.given().filter(new AllureRestAssured())
                .contentType("application/json")
                .body(chekoutOptionRestApi.createJsonFileWithArrayForSave(criteria , value , values))
                .when()
                .post("http://172.21.21.83:8080/checkout-aggregation/checkout-option/" + id + "/criteria")
                .then()
                .statusCode(200)
                .log()
                .all()
                .extract()
                .response();


    }

    @Test
    public void deleteCriteria(String id, String criteria) {

        CheckoutOptionRestApi chekoutOptionRestApi = new CheckoutOptionRestApi();

        Response response = RestAssured.given().filter(new AllureRestAssured())
                .contentType("application/json")
                .body(chekoutOptionRestApi.createJsonFileForDelete(criteria))
                .when()
                .delete("http://172.21.21.83:8080/checkout-aggregation/checkout-option/" + id + "/criteria")
                .then()
                .statusCode(200)
                .log()
                .all()
                .extract()
                .response();


    }

    @Test
    public void updateCriteria(String id, String criteria, String value , String values) {

        CheckoutOptionRestApi chekoutOptionRestApi = new CheckoutOptionRestApi();

        Response response = RestAssured.given().filter(new AllureRestAssured())
                .contentType("application/json")
                .body(chekoutOptionRestApi.createJsonFileForUpdate(criteria, value, values))
                .when()
                .put("http://172.21.21.83:8080/checkout-aggregation/checkout-option/" + id + "/criteria")
                .then()
                .statusCode(200)
                .log()
                .all()
                .extract()
                .response();

    }

    @Test
    public void cacheEvict() {
        Response response = RestAssured.given().filter(new AllureRestAssured())
                .when()
                .get("http://172.21.21.83:8080/checkout-aggregation/checkout-option/cache/evict")
                .then()
                .statusCode(200)
                .log()
                .all()
                .extract()
                .response();

    }
}
