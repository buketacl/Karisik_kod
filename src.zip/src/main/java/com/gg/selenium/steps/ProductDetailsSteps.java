package com.gg.selenium.steps;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

import com.gg.selenium.base.Common;
import com.gg.selenium.driver.Driver;
import com.gg.selenium.utils.RestOperations;
import com.gg.selenium.utils.SystemUtils;
import com.thoughtworks.gauge.Step;
import com.thoughtworks.gauge.datastore.ScenarioDataStore;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Implements steps definitions related to Product Page.
 */
@Component
public class ProductDetailsSteps {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProductDetailsSteps.class);
    private static final String CART_URL = "cart_url";
    private static final String CART_PRODUCT_TITLE = "cart_product_title";

    private final Common common;
    private final SystemUtils systemUtils;
    private final RestOperations restOperations;

    public ProductDetailsSteps(final Common common,
                               final SystemUtils systemUtils,
                               final RestOperations restOperations) {
        this.common = common;
        this.systemUtils = systemUtils;
        this.restOperations = restOperations;
    }

    /**
     * User adds the product to the cart.
     */
    @Step("User adds the product to the cart web")
    public void userAddsTheProductToTheCartWeb() {
        common.clickElementDota("product_page_add_to_basket");
        try {
            common.waitUntilElementIsVisible("basket_pop_up");
        } catch (TimeoutException e) {
            // TimeoutException means that basket_pop_up is not displayed. In that case we're checking if gg-info-box
            // is displayed as it's an alert box indicating a problem that may be related to xhr endpoints.
            if (common.findElementDota("gg_info_box").isDisplayed()) {
                LOGGER.error("THE PRODUCT COULDN'T BE ADDED TO CART!\n"
                        + "gg-info-box with message 'Ürün sepetinize eklenirken bir hata oluştu' "
                        + "should not be displayed"
                        + "here!\nThere may be an XHR problem");
            }
            throw e;
        }
        userShouldSeeBasketPopUpAndBasketAmountEqual();
        common.clickElementDota("basket_pop_up_go_to_cart");

        common.waitUntilPageLoaded();

        checkTitleAndAddProductToCart();
    }

    /**
     * User adds the product to the cart resp.
     */
    @Step("User adds the product to the cart resp")
    public void userAddsTheProductToTheCartResp() {
        common.clickElementDota("product_page_add_to_basket");
        common.waitUntilPageLoaded();

        checkTitleAndAddProductToCart();
    }

    /**
     * User decides to accept/refuse fixpack.
     *
     * @param acceptFixpack Whether or not to accept the fixpack.
     */
    @Step("User decides to add fixpack <trueORfalse>")
    public void userDecidesToRefuseFixpack(final boolean acceptFixpack) {
        if (acceptFixpack) {
            common.clickElementDota("add_fixpack");
            common.refresh();
            common.goToUrl(systemUtils.readEnv(CART_URL));
            common.waitUntilPageLoaded();
            List<WebElement> webElementsList = common.findElementsDota(CART_PRODUCT_TITLE);
            boolean fixpackPoductInBasket = false;
            for (int i = 0; i < webElementsList.size(); i++) {
                if (webElementsList.get(i).getText().startsWith("fixpack")) {
                    fixpackPoductInBasket = true;
                    break;
                } else {
                    LOGGER.info("Sepetteki {}. urun fixpack urunu degil.", i + 1);
                }
            }
            assertThat("No fixpack product in basket", fixpackPoductInBasket, is(true));
        } else {
            common.clickElementDota("continue_to_basket");
            common.waitUntilAjaxLoaded();
            common.goToUrl(systemUtils.readEnv(CART_URL));
            common.waitUntilPageLoaded();
            for (int i = 0; i < common.findElementsDota("cart_seller_name").size(); i++) {
                assertThat(
                        common.findElementsDota("cart_seller_name").get(i).getText(),
                        is(not(equalTo("fixpack")))
                );
            }
        }
    }

    /**
     * Increases product amount by pressing the plus icon. DO NOT use to add many product.
     *
     * @param amountOfProduct the amount of product
     */
    @Step("User increases product amount by pressing the plus icon <amount> time(s) on product page")
    public void userIncreasesProductAmountByPressingPlusIconOnProductPage(
            final String amountOfProduct) {
        int oldAmount = Integer.parseInt(common.getProperty("product_page_product_amount", "value"));
        for (int i = 0; i < Integer.parseInt(amountOfProduct); i++) {
            common.clickElementDota("plus_icon");
        }
        int totalAmount = oldAmount + Integer.parseInt(amountOfProduct);
        int productPageProAmount = Integer
                .parseInt(common.getProperty("product_page_product_amount", "value"));
        assertThat("Product amount couldn't increased", totalAmount, is(equalTo(productPageProAmount)));

        ScenarioDataStore.put("productPageProductAmount", totalAmount);
    }

    /**
     * User should add complementary products to basket.
     */
    @Step("User should add complementary products to basket for web")
    public void userShouldAddComplementaryProductsToBasket() {
        int complementaryProductCount = common.findElementsDota("complementary_products").size() + 1;
        common.clickElementDota("complementary_add_to_basket_button");
        common.waitUntilElementIsVisible("basket_pop_up");
        common.goToUrl(systemUtils.readEnv(CART_URL));
        common.waitUntilPageContainsElement("products_container");
        int basketProductCount = common.findElementsDota(CART_PRODUCT_TITLE).size();
        assertThat(
                "complementary product couldnt added to basket ",
                basketProductCount, is(equalTo(complementaryProductCount))
        );

    }

    /**
     * User should add complementary products to basket for responsive.
     */
    @Step("User should add complementary products to basket for responsive")
    public void userShouldAddComplementaryProductsToBasketForResponsive() {
        int complementaryProductCount = common.findElementsDota("complementary_products").size() + 1;
        common.clickElementDota("complementary_add_to_basket_button");
        common.waitUntilPageContainsElement("products_container");
        int basketProductCount = common.findElementsDota(CART_PRODUCT_TITLE).size();
        assertThat(
                "complementary product couldnt added to basket ",
                basketProductCount, is(equalTo(complementaryProductCount))
        );

    }

    /**
     * User clicks fixpack checkbox to add fixpack to basket for responsive.
     */
    @Step("User clicks fixpack checkbox for responsive")
    public void userClicksFixPackCheckBoxForResponsive() {
        common.checkCheckBox("fixpack_div", "fixpack_checkbox");
    }

    /**
     * User should see basket pop-up and quantity of product.
     */
    public void userShouldSeeBasketPopUpAndBasketAmountEqual() {
        assertThat("The product quantity is not as expected",
                common.findElementsDota("basket_pop_up_total_item_count").size(),
                is(equalTo(common.findElementsDota("basket_item_count").size())));
    }

    /**
     * User selects first variant. (The variant which has not selected default)
     */
    @Step("User selects first variant")
    public void userSelectEnableVariant() {
        String oldProductColor = common.findElementDota("variant_color_text").getText();
        common.findElementsDota("enable_variant").get(0).click();
        common.waitUntilAjaxLoaded();
        String newProductColor = common.findElementDota("variant_color_text").getText();
        assertThat(oldProductColor, not(equalTo(newProductColor)));
        String[] newProductColorParts = newProductColor.split(":");
        ScenarioDataStore.put("newProductColor", newProductColorParts[1].trim());


    }

    /**
     * User should see selected product in basket.
     */
    @Step("User should see the correct variant of the selected product in the basket")
    public void userShouldSeeSelectedProductInBasket() {
        String productColorInBasket = common.findElementDota("selected_product_properties").getText();
        String[] productColorInBasketParts = productColorInBasket.split(":");
        String newProductColor = ScenarioDataStore.get("newProductColor").toString();
        assertThat(
                String.format("The colors of the products did not match. "
                        + "Expected: %s  Actual: %s", newProductColor, productColorInBasketParts[1].trim()),
                productColorInBasketParts[1].trim().contains(newProductColor), is(true)
        );
    }

    /**
     * User goes to product page by using product id.
     */
    @Step("User goes to product page then sees sellers")
    public void userGoesToProductPageForMultipleSeller() {
        String productId = restOperations.returnsProductIdForMultipleSellers();
        ScenarioDataStore.put("oldProductId", productId);
        common.goToCustomizedUrl("urun_gg", productId);
        common.waitUntilAjaxLoaded();
        common.waitUntilElementIsVisible("spp_product_page_title");

    }

    /**
     * User selects another seller in product page.
     */
    @Step("User should be able to select other seller's product")
    public void userShouldSelectsOthersProduct() {
        String oldProductId = ScenarioDataStore.get("oldProductId").toString();
        common.returnsWebElementAccordingToIndex("other_sellers_product", 0).click();
        common.waitUntilAjaxLoaded();
        common.waitUntilPageLoaded();
        String newProductId = common.waitUntilPageContainsElement("description_tab_product_id")
                .getText();
        Assertions.assertNotEquals(oldProductId, newProductId,
                "Other seller's product could not be selected");
    }

    /**
     * User should see seller explanation is correct.
     *
     * @param sellerExplanation sellerExplanation such as İkinci El ,N&D etc.
     */
    @Step("User should see product is <seller explanation spec>")
    public void userShouldSeeSellerExplanationIsCorrect(final String sellerExplanation) {
        common.findElementDota("seller_explanation").click();
        checkIfSellerExplanationIsCorrect(sellerExplanation);
    }

    /**
     * Asserts seller explanation is correct.
     *
     * @param sellerExplanation sellerExplanation such as İkinci El etc. for resp.
     */
    @Step("User should see product is <seller explanation spec> for resp")
    public void userShouldSeeSellerExplanationIsCorrectForResp(final String sellerExplanation) {
        checkIfSellerExplanationIsCorrect(sellerExplanation);
    }

    /**
     * Checks if seller explanation on product page is match with given text.
     *
     * @param givenText given text
     */
    public void checkIfSellerExplanationIsCorrect(final String givenText) {
        List<WebElement> webElementList = common.findElementsDota("seller_explanation_specs");
        boolean isContain = false;
        for (WebElement webElement : webElementList) {
            String webElementText = webElement.getText();
            if (webElementText.contains(givenText)) {
                isContain = true;
            }
        }
        Assertions.assertTrue(isContain, "Seller explanation is not correct");
    }

    /**
     * Clicks add to favorite button on product page.
     */
    @Step("User clicks add to favorite button")
    public void userClicksAddToFavoriteButton() {
        common.clickElementDota("add_to_favorite");
    }

    /**
     * Scrolls to watch_share_report div on product page.
     */
    @Step("User scrolls to seller explanation title")
    public void userScrollsFavoriteButton() {
        common.scrollToElement("seller_explanation_title");
    }

    private void checkTitleAndAddProductToCart() {
        String title = Driver.getWebDriver().getTitle();
        String errorMessage = "Page title is not correct!";
        assertThat(errorMessage, title, containsString(systemUtils.readEnv("cart_title")));

        List<WebElement> productsAdded = Driver.getWebDriver()
                .findElements(common.by("product_item_box"));
        assertThat("Product could not be added to the cart.", !productsAdded.isEmpty());
    }
}
