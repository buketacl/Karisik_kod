package com.gg.selenium.steps;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;

import com.gg.selenium.base.Common;
import com.gg.selenium.driver.Driver;
import com.gg.selenium.exceptions.RestException;
import com.gg.selenium.services.ProductHelperService;
import com.gg.selenium.services.responses.ProductHelperResponse;
import com.gg.selenium.utils.SystemUtils;
import com.gg.selenium.utils.Util;
import com.thoughtworks.gauge.AfterScenario;
import com.thoughtworks.gauge.Step;
import com.thoughtworks.gauge.datastore.ScenarioDataStore;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;


/**
 * Implements steps definitions related to ListingSteps.
 */
@Component
public class ListingSteps {

  private final Common common;
  private final SystemUtils systemUtils;
  private final ProductHelperService productHelperService;

  public ListingSteps(final Common common,
      final SystemUtils systemUtils,
      final ProductHelperService productHelperService) {
    this.common = common;
    this.systemUtils = systemUtils;
    this.productHelperService = productHelperService;
  }

  /**
   * Clicks draft tab on https://www.gittigidiyor.com/urun-satmak/kategori-secim.
   */
  @Step("User clicks draft tab")
  public void userClicksdraftTab() {
    common.clickElementDota("ready_drafts_tab");
    common.waitUntilElementIsVisible("draft_container");
  }

  /**
   * Mouse over draft container.
   */
  @Step("User mouse over draft container")
  public void userMouseOverDraftContainer() {
    common.scrollToElement("draft_container");
    common.waitUntilElementIsVisible("use_draft_button");

  }

  /**
   * Clicks use button on draft container.
   */
  @Step("User clicks use draft button")
  public void userClicksUseDraftButton() {
    common.clickElementDota("use_draft_button");
    String url = systemUtils.readEnv("listing_editting_draft_url");
    Driver.getDriverWait().until(ExpectedConditions.urlContains(url));
  }


  /**
   * Clicks change category button.
   */
  @Step("User clicks change category button")
  public void userClicksChangeCategoryButton() {
    common.scrollToElement("change_draft_category_button");
    common.returnsWebElementAccordingToIndex("change_draft_category_button", 0).click();
    String sellingProductUrl = systemUtils.readEnv("change_product_category");
    Driver.getDriverWait().until(ExpectedConditions.urlContains(sellingProductUrl));

  }

  /**
   * Selects product category  on  https://www.gittigidiyor.com/urun-satmak/urun/${productId}.
   */
  @Step("User selects product category")
  public void userSelectsProductCategory() {
    common.clickElementDota("listing_category");
    common.clickElementDota("continue_button");
    common.waitUntilElementIsVisible("without_variant");

  }

  /**
   * Increases product amount on  https://www.gittigidiyor.com/urun-satmak/adet-secim/urun/${productId}.
   */
  @Step("User increases product amount on listing page")
  public void userSelectsProductAmount() {
    common.clearText("listing_product_count");
    common.inputText("listing_product_count", "3");
    common.clickElementDota("blue_continue_button");
    common.waitUntilElementIsVisible("selling_product_info");

  }

  /**
   * Selects selling type choose on https://www.gittigidiyor.com/urun-satmak/tur-secim/urun/${productId}.
   */
  @Step("User selects product without variant")
  public void userSelectsProductType() {
    common.clickElementDota("without_variant");

  }

  /**
   * Fills listing information  on https://www.gittigidiyor.com/urun-satmak/urun/${productId}.
   */
  @Step("User fills listing information")
  public void userFillsListingInformation() {

    common.clearText("product_name");
    common.inputText("product_name", "__ggtest Listing Product");

    String productListingCount = common.getProperty("product_listing_count", "value");
    assertThat("Product amount couldn't enter", "3".equals(productListingCount));

    common.clearText("listing_product_price");
    common.inputText("listing_product_price", "20");

    common.inputText("listing_product_price_decimal", "00");

  }

  /**
   * Selects first enable product feature from dropdowns on https://www.gittigidiyor.com/urun-satmak/urun/${productId}.
   *
   * @param locator Dropdown(s)'s cssSelector
   */
  @Step("User selects first enable product feature from dropdowns <dropDownLocator>")
  public void userSelectsProductFeatureDropdowns(final String locator) {
    common.selectFirstEnableOptionFromDropDown(locator);
  }

  /**
   * Proceeds to  https://www.gittigidiyor.com/urun-satmak/satis-onizleme/urun/${productId}.
   */
  @Step("User proceeds to product description")
  public void userProceedToProductDescription() {
    common.clickElementDota("listing_confirm_product");
    common.waitUntilElementIsVisible("review_product_title");
    String currentUrl = common.getLocation();
    String assertMessage = "Product information missing or continue button couldnt click";
    assertThat(assertMessage, currentUrl, containsString("satis-onizleme"));

  }

  /**
   * Proceeds to https://www.gittigidiyor.com/urun-satmak/satis-ekstralar/urun/${productId}.
   */
  @Step("User proceeds to product preview and verify")
  public void userProceedToProductPreviewAndVerify() {
    common.clickElementDota("listing_primary_continue_button");
    String currentUrl = common.getLocation();
    assertThat("Continue button couldnt click ", currentUrl, containsString("reklam-paketi"));


  }


  /**
   * Lists product for free.
   */
  @Step("User lists product for free")
  public void userListingProductForFree() {
    common.clickElementDota("listing_product");
    parseProductIdFromListingUrl(common.getLocation());
    assertThat("Continue button couldnt click ", common.getLocation(),
        containsString("reklam-paketi"));


  }


  /**
   * Goes to created product with product id.
   */
  @Step("User goes to created product")
  public void userControlsCreatedProduct() {
    String productId = ScenarioDataStore.get("ProductId").toString();
    common.goToCustomizedUrl("urun_gg", productId);
  }

  /**
   * Verify created the product successfully created.
   */
  @Step("User should see the product successfully created")
  public void userShouldSeeTheProductSuccesfullyCreated() {
    String productTitle = common.findElementDota("spp_product_page_title").getText();
    assertThat("Product title couldn't match", "__ggtest Listing Product".equals(productTitle));
    common.waitUntilElementIsVisible("spp_product_price_container");
    common.waitUntilElementIsVisible("spp_product_purchase_buttons");

  }


  /**
   * Gets productId from  https://www.gittigidiyor.com/urun-satmak/satis-basarili/urun/${productId}/0.
   *
   * @param url Given url
   */
  private void parseProductIdFromListingUrl(final String url) {
    String[] urlParts = url.split("/");
    String product = urlParts[urlParts.length - 1];
    ScenarioDataStore.put("ProductId", product);


  }

  /**
   * Clears unfinished draft after listing a product.
   */
  @AfterScenario(tags = {"clear-unfinished-draft"})
  public void userClearUnfinishedDraft() {
    common.goToUrl(systemUtils.readEnv("listing_unfinised_draft"));
    List<WebElement> unfinishedDraft;
    do {

      unfinishedDraft = common.findElementsDota("draft_name");
      if (!unfinishedDraft.isEmpty()) {
        Driver.getActions().moveToElement(unfinishedDraft.get(0)).perform();
        common.clickElementDota("delete_draft");

      }

    } while (!unfinishedDraft.isEmpty());
    common.waitUntilElementIsVisible("unfinised_draft_area");
  }


  /**
   * Clears active sales after listing a product.
   */
  @AfterScenario(tags = {"clear-active-sales-listing-products"})
  public void userClearActiveSalesProduct() {
    common.goToUrl(systemUtils.readEnv("listing_service"));
    common.clickElementDota("finish_early_button");
    common.waitUntilElementIsVisible("listing_select_all_ready_products");
    common.clickElementDota("listing_select_all_ready_products");
    common.clickElementDota("finish_early_button");
    common.locationShouldBe(systemUtils.readEnv("listing_update_product"));
    common.clickElementDota("listing_confirm_update");
    common.locationShouldBe(systemUtils.readEnv("listing_service"));
  }

  /**
   * Clears active sales after listing a product.
   */
  @AfterScenario(tags = {"clear-ready-to-listing-products"})
  public void userClearSavedListingProduct() {
    common.goToUrl(systemUtils.readEnv("ready_to_listing"));
    if (common.findElementDota("listing_select_all_ready_products").isDisplayed()) {
      common.scrollToElement("listing_select_all_ready_products");
      common.clickElementDota("listing_select_all_ready_products");
      common.clickElementDota("delete_product");
      common.clickElementDota("listing_confirm_update");
      common.waitUntilElementIsVisible("success_message");
    }

  }

  /**
   * @param productName given product name
   */
  @Step("Save product as a draft <productName>")
  public void saveProductAsDraft(final String productName) throws RestException {
    common.goToUrl(systemUtils.readEnv("taslak_secim"));
    if (!common.doesPageContainGivenText(productName)) {
      saveAsDraft(productName);
    }
    common.goToUrl(systemUtils.readEnv("gittigidiyor"));
  }

  /**
   * @param productName given product name.
   * @return template id.
   */
  public String getProductTemplateIdFromUrl(final String productName) throws RestException {
    final Optional<ProductHelperResponse> optionalProduct = productHelperService
        .getTestProductId(productName);
    if (!optionalProduct.isPresent()) {
      throw new RestException("Unable to product id from dota product helper: " + productName);
    }
    final String productId = optionalProduct.get().getProductId();
    String productRevisionLink =
        "https://www.gittigidiyor.com/urun-satmak/sell-same/" + productId + "/0/online";
    common.goToUrl(productRevisionLink, "urun-satmak");
    return common.getLocation().substring(common.getLocation().lastIndexOf('/') + 1);
  }

  /**
   * @param productName given product name.
   */
  public void saveAsDraft(final String productName) throws RestException {
    String templateId = getProductTemplateIdFromUrl(productName);
    String saveAsDraft =
        "https://www.gittigidiyor.com/urun-satmak/save-as-template/" + templateId + "/offline/2";
    common.goToUrl(saveAsDraft, "satis-basarili");
    common.goToUrl(systemUtils.readEnv("taslak_secim"));
    Assertions.assertTrue(common.doesPageContainGivenText(productName));
  }

  /**
   * User selects selling type such as sabit fiyat etc.
   */
  @Step("User selects selling type")
  public void userSelectsSellingType() {
    common.clickElementDota("blue_continue_button");
    common.waitUntilElementIsVisible("product_name");
  }

  /**
   * User goes to ready to listing products page.
   */
  @Step("User sees ready to listing products")
  public void userSeesReadyToListingProducts() {
    common.waitUntilElementIsVisible("ready_to_listing_products_table");
  }


  /**
   * User clicks edit multiple button product on listing service.
   */
  @Step("User clicks edit multiple button product on listing service")
  public void userClicksEditMultipleProductOnListingService() {
    common.scrollToElement("pager_size");
    common.clickElementDota("listing_select_all_ready_products");
    common.clickElementDota("edit_multiple_products_button");
    common.locationShouldBe("duzenlenecek-alanlar");
  }

  /**
   * User chooses the part to be edited of products.
   */
  @Step("User chooses the part to be edited of products")
  public void userChoosesThePartToBeEditedOfProducts() {
    common.checkCheckBox("edit_product_amount_label", "edit_product_amount_input");
  }

  /**
   * User chooses product edit method such as "Çoklu Düzenle" or "Hızlı düzenle" .
   */
  @Step("User chooses product edit method")
  public void userChoosesProductEditMethod() {
    common.clickElementDota("edit_multiple_label");
    common.clickElementDota("listing_confirm_update");
    common.locationShouldBe("toplu-urun-duzenleme");
  }

  /**
   * Changes product amount for multiple products randomly.
   */
  @Step("User should be able to changes product amount for multiple products")
  public void userShouldBeAbleToChangesProductAmountForMultipleProducts() {
    final int randomNumber = Util.generateRandomNumber(1, 10);
    common.inputText("product_amount", String.valueOf(randomNumber));
    common.clickElementDota("listing_confirm_update");
    common.waitUntilElementIsVisible("success_message");
  }
}


