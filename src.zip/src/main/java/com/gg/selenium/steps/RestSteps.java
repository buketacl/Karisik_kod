package com.gg.selenium.steps;

import com.gg.selenium.base.Common;
import com.gg.selenium.utils.RestOperations;
import com.gg.selenium.utils.SystemUtils;
import com.thoughtworks.gauge.Step;
import org.springframework.stereotype.Component;


/**
 * Implements steps definitions that use REST requests.
 */
@Component
public class RestSteps {

  private final Common common;
  private final SystemUtils systemUtils;
  private final RestOperations restOperations;

  public RestSteps(final Common common, final SystemUtils systemUtils,
      final RestOperations restOperations) {
    this.common = common;
    this.systemUtils = systemUtils;
    this.restOperations = restOperations;
  }

  /**
   * Checks if user has non-default addresses and if so, deletes them all.
   */
  @Step("Clears non-default address(es) with rest request")
  public void deleteAllAddresses() {
    restOperations.deleteAllAddressesWithUserId();
  }

  /**
   * Clears basket by using rest request.
   */
  @Step("Clears basket with rest request")
  public void clearBasketWithRestRequest() {
    common.goToUrl(systemUtils.readEnv("cart_url"));
    restOperations.deleteCartItems();
  }

}
