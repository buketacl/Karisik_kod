package com.gg.selenium.steps;

import com.gg.selenium.base.Common;
import com.gg.selenium.driver.Driver;
import com.gg.selenium.utils.RestOperations;
import com.gg.selenium.utils.SystemUtils;
import com.thoughtworks.gauge.Step;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;


/**
 * Implements steps definitions related to HomepageSteps.
 */
@Component
public class HomepageSteps {

    private static final Logger LOGGER = LoggerFactory.getLogger(HomepageSteps.class);

    private final Common common;
    private final SystemUtils systemUtils;

    public HomepageSteps(final Common common, final SystemUtils systemUtils) {
        this.common = common;
        this.systemUtils = systemUtils;
    }

    /**
     * Clicks sell button.
     */
    @Step("User clicks selling button")
    public void userClicksSellproduct() {
        common.clickElementDota("sell_product_link");
        Driver.getDriverWait().until(ExpectedConditions.urlToBe(systemUtils.readEnv("listing_sell_product_url")));

    }

    /**
     * Checks homepage(Gobek Banner) campaign url working correctly.
     */
    public void verifyCampaignBannersStatus200() {
        String assertMessage = "Campaign Banner's status is not 200 ";
        List<WebElement> webElementList = common.findElementsDota("homepage_banners");
        for (WebElement webElement : webElementList) {
            String campaignUrl = webElement.getAttribute("data-href");
            campaignUrl = addHttpsIfNotStartsWith(campaignUrl);
            int campaignUrlStatus = RestOperations.getUrlStatus(campaignUrl);
            LOGGER.info("campaignUrl :{} Status : {}", campaignUrl, campaignUrlStatus);
            Assertions.assertEquals("200", String.valueOf(campaignUrlStatus), assertMessage);
        }

    }

    /**
     * If given url is not starting with https this method adds https: to url.
     *
     * @param url given url
     * @return returns https added url
     */
    public String addHttpsIfNotStartsWith(final String url) {
        String lowerCaseUrl = url.toLowerCase();
        if (!lowerCaseUrl.startsWith("https")) {
            return String.format("https:%s", url);
        }
        return lowerCaseUrl;
    }


    /**
     * Checks campaigns' urls working correctly.
     */
    @Step("Campaign url's status should be 200")
    public void campaignBannersResponseShouldBe200() {
        verifyCampaignBannersStatus200();
    }


    /**
     * Clicks profile icon for resp.
     */
    @Step("User clicks profile icon for resp")
    public void userClicksProfileIconForResp() {
        common.waitUntilAjaxLoaded();
        common.clickElementDota("homepage_profile_icon");
        common.waitUntilElementIsVisible("profile_information_div");
    }
}

