package com.gg.selenium.steps;

import com.gg.selenium.base.Common;
import com.gg.selenium.data.UserRepository;
import com.gg.selenium.models.User;
import com.gg.selenium.utils.LoginController;
import com.gg.selenium.utils.SystemUtils;
import com.thoughtworks.gauge.Step;
import com.thoughtworks.gauge.datastore.ScenarioDataStore;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Implements steps definitions related to My Page.
 */
@Component
public class MyPageSteps {

  private static final Logger LOGGER = LoggerFactory.getLogger(MyPageSteps.class);

  private final Common common;
  private final SystemUtils systemUtils;

  public MyPageSteps(final Common common, final SystemUtils systemUtils) {
    this.common = common;
    this.systemUtils = systemUtils;
  }

  /**
   * @param memberInformation such as , Adres bilgilerimi güncelle or Kişisel bilgilerimi güncelle
   *                          on Bana Ozel.
   */
  @Step("User clicks <memberInformation>")
  public void userClicksGivenInformation(final String memberInformation) {
    common.clickWebElementAccordingToText("member_information", memberInformation);
    common.waitUntilPageLoaded();
  }

  /**
   * User should see default address.
   */
  @Step("User should see default address")
  public void userShouldSeeDefaultAddress() {
    common.waitUntilElementIsVisible("user_default_address_container");
  }


  /**
   * User first clicks Bilgilerim then clicks Adres Bilgilerim .
   */
  @Step("User clicks Bilgilerim/Adres Bilgilerim for resp")
  public void userClicksMyAddressesForResp() {
    common.clickWebElementAccordingToText("main_member_information", "Bilgilerim");
    common.waitUntilAjaxLoaded();
    common.clickWebElementAccordingToText("sub_member_information", "Adres Bilgilerim");
    common.waitUntilPageLoaded();
  }

  /**
   * User should be able to see product information detail on "Siparislerim" page.
   */
  @Step("User should be able to see product information detail")
  public void userShouldBeAbleToSeeDetailProductInfo() {
    common.waitUntilElementIsVisible("mypage_product_container");
    common.waitUntilElementIsVisible("mypage_seller_info_on_product");
    common.waitUntilElementIsVisible("mypage_process_info_on_product");
    common.waitUntilElementIsVisible("mypage_product_status_container");
  }


  /**
   * User should be able to see product information detail for resp on "Siparislerim" page.
   */
  @Step("User should be able to see product information detail for resp")
  public void userShouldBeAbleToSeeDetailProductInfoForResp() {
    common.waitUntilElementIsVisible("bought_product_picture");
    common.waitUntilElementIsVisible("bought_product_information");
    common.waitUntilElementIsVisible("bought_product_detail_arrow");
  }

  /**
   * Checks if favorite page components are visible.
   */
  @Step("User should see favorite product")
  public void userShouldSeeFavoriteProduct() {
    common.waitUntilElementIsVisible("favorite_product_title");
    common.waitUntilElementIsVisible("favorite_product_shipping");
    common.waitUntilElementIsVisible("favorite_product_add_to_basket");
    common.waitUntilElementIsVisible("favorite_product_quick_buy");
    common.waitUntilElementIsVisible("favorite_product_price");
    common.waitUntilElementIsVisible("favorite_product_seller");

  }


  /**
   * Deletes favorite products.
   */
  @Step("User deletes favorite products")
  public void userDeletesFavoriteProduct() {
    common.goToUrl(systemUtils.readEnv("all_campaigns"));
    common.goToUrl(systemUtils.readEnv("favorite_page"));
    String emptyFavoritePageText = "İzlediklerim listenizde ürün bulunmamaktadır.";
    if (!common.doesPageContainGivenText(emptyFavoritePageText)) {
      common.checkCheckBox("favorite_products_checkbox", "favorite_product_checkbox_input");
      common.clickElementDota("favorite_product_delete_button");
      common.waitUntilElementIsVisible("favorite_products_delete_message");
    } else {
      LOGGER.info("There are no products added to my favorites");
    }
  }


  /**
   * User should be able to see discount coupons page components.
   */
  @Step("User should be able to see discount coupons page components")
  public void userShouldBeAbleToSeeDiscountCouponsPageComponents() {
    common.waitUntilElementIsVisible("discount_name");
    common.waitUntilElementIsVisible("discount_button");
    common.waitUntilElementIsVisible("discount_input");
    common.waitUntilElementIsVisible("promotions_list");
  }

  /**
   * User goes to my page pages from homepage by clicking profile icon.
   *
   * @param page such as Siparislerim , Urun yonetimi.
   */
  @Step("User goes to <MyPages> by using user panel")
  public void userGoesToMyPagesByUsingUserPanel(final String page) {
    common.scrollToElement("profile_icon");
    common.waitUntilElementIsVisible("homepage_user_menu_panel");
    common.clickWebElementAccordingToText("homepage_user_menu_content", page);
    common.waitUntilPageLoaded();
  }

  /**
   * User goes to my page pages from homepage by clicking profile icon for resp.
   *
   * @param page such as Siparislerim , Urun yonetimi.
   */
  @Step("User goes to <MyPages> by using user panel for resp")
  public void userGoesToMyPagesByUsingUserPanelForResp(final String page) {
    common.clickElementDota("profile_icon");
    common.waitUntilElementIsVisible("homepage_user_menu_panel");
    common.clickWebElementAccordingToText("homepage_user_menu_content", page);
    common.waitUntilPageLoaded();

  }

  /**
   * User should be able to see sale product information detail.
   */
  @Step("User should be able to see sale product information detail")
  public void userShouldBeAbleToSeeSaleProductInformationDetail() {
    common.waitUntilElementIsVisible("mypage_product_container");
    common.waitUntilElementIsVisible("sattiklarim_transactions");
    common.waitUntilElementIsVisible("sattiklarim_buyer_information");
    common.waitUntilElementIsVisible("mypage_product_status_container");
  }

  /**
   * User should be able to add bank account.
   */
  @Step("User should be able to add bank account")
  public void userShouldBeAbleToAddBankAccount() {
    common.inputText("bank_account_owner_name", "Test Kullanicisi Hesabi");
    common.findElementDota("iban_input").click();
    common.inputText("iban_input", systemUtils.readEnv("iban"));
    common.selectFirstEnableOptionFromDropDown("bank_name");
    common.waitUntilAjaxLoaded();
    common.scrollToElement("confirm_bank_account");
    common.selectFirstEnableOptionFromDropDown("bank_city");
    common.waitUntilAjaxLoaded();
    common.scrollToElement("confirm_bank_account");
    common.selectFirstEnableOptionFromDropDown("bank_office");
    common.clickElementDota("confirm_bank_account");

    User user = UserRepository.USERS.get(ScenarioDataStore.get(LoginController.USER_ID));
    common.findElementDota("password_input").sendKeys(user.getPassword());

    common.clickElementDota("login_page_login_button");
    Assertions.assertTrue(common.doesPageContainGivenText("Test Kullanicisi Hesabi"));
  }

  /**
   * User deletes if user has a bank account.
   */
  @Step("User deletes if user has a bank account")
  public void userDeletesBankAccount() {
    common.goToUrl(systemUtils.readEnv("all_campaigns"));
    common.goToUrl(systemUtils.readEnv("my_bank_account"));
    if (!common.doesPageContainGivenText("Henüz tanımlanmış bir banka hesabınız yoktur")) {
      deleteBankAccount();
    }
    LOGGER.info("User does not have a bank account");
  }

  /**
   * Used for delete account.
   */
  public void deleteBankAccount() {
    common.clickElementDota("delete_bank_account");
    common.clickElementDota("delete_bank_account_confirm");

    User user = UserRepository.USERS.get(ScenarioDataStore.get(LoginController.USER_ID));
    common.findElementDota("password_input").sendKeys(user.getPassword());

    common.clickElementDota("login_page_login_button");
    Assertions.assertTrue(
        common.doesPageContainGivenText("Seçtiğiniz banka hesabı başarı ile silinmiştir!"));
  }

  /**
   * Statically written texts are for control purposes. User should be able to submit new address
   * information on my page.
   */
  @Step("User should be able to submit new address information on my page")
  public void userShouldBeAbleToSubmitNewAddressInformationOnMyPage() {
    final int textLength = 5;
    common.inputText("new_address_title", "Silinecek");
    common.inputGeneratedText("new_address_username", textLength);
    common.inputGeneratedText("new_address_surname", textLength);
    common.selectFirstEnableOptionFromDropDown("new_address_city");
    common.waitUntilAjaxLoaded();
    common.selectFirstEnableOptionFromDropDown("new_address_county");
    common.waitUntilAjaxLoaded();
    common.selectFirstEnableOptionFromDropDown("new_address_neighbor");
    common.inputText("new_address_address_detail", "Test basladıgında bu test silinmiş olmalı");
    common.inputGeneratedPhoneNumber("new_address_cell_phone");

    common.inputText("new_address_zip_code", "34500");
    common.clickElementDota("new_address_save");
    common.waitUntilPageLoaded();
    common.locationShouldBe(systemUtils.readEnv("my_addresses"));
    List<WebElement> addresses = common.findElementsDota("address_name");
    Assertions.assertEquals("2", String.valueOf(addresses.size()), "Address could not added.");
    Assertions.assertEquals("Silinecek", addresses.get(1).getText(),
        "Address could not added correctly.");
  }

  /**
   * User clicks new address button on my addresses page.
   */
  @Step("User clicks new address button on my addresses page")
  public void userClicksAddNewAddressButtonOnMyAddressesPage() {
    common.clickElementDota("add_new_address");
    common.waitUntilPageLoaded();
    common.locationShouldBe(systemUtils.readEnv("add_new_address_url"));
  }

  /**
   * Changes default address information on my page.
   */
  @Step("User should be able to change default address information on my page")
  public void userShouldBeAbleToChangeDefaultAddressOnMyPage() {
    common.clickElementDota("set_default_address_button");
    common.waitUntilElementIsVisible("set_default_success_message");
  }
}
