package com.gg.selenium.steps;

import com.gg.selenium.base.Common;
import com.gg.selenium.driver.Driver;
import com.gg.selenium.utils.SystemUtils;
import com.thoughtworks.gauge.Step;
import org.openqa.selenium.JavascriptExecutor;
import org.springframework.stereotype.Component;

/**
 * Implements steps definitions related to All Campaigns Page.
 */
@Component
public class AllCampaignsSteps {

    private final Common common;
    private final SystemUtils systemUtils;

    public AllCampaignsSteps(final Common common, final SystemUtils systemUtils) {
        this.common = common;
        this.systemUtils = systemUtils;
    }


    /**
     * Successful login and badge control for kazananlar kulubu users.
     */
    @Step("User should see kk icon")
    public void userShouldSeeKkIcon() {
        common.waitUntilElementIsVisible("loyalty_icon");
    }

    /**
     * Clicks to all campaigns page.
     */
    @Step("User clicks on all campaigns page")
    public void userClicksOnAllCampaignsPage() {
        common.goToUrl(systemUtils.readEnv("gittigidiyor"));
        common.clickElementDota("all_campaigns_on_homepage");
        common.locationShouldBe(systemUtils.readEnv("all_campaigns"));
    }

    /**
     * Clicks to all campaigns page click banner.
     */
    @Step("User clicks the banner on all campaigns page")
    public void userClicksTheBannerOnAllCampaignsPage() {
        common.waitUntilElementIsVisible("cmpg_banner");
        common.scrollToElement("cmpg_banner_wrapper");
        common.clickElementDota("all_campaigns_banner_click");
    }

    /**
     * User should see campaign detail.
     */
    @Step("User should see campaign detail")
    public void userShouldSeeCampaignDetail() {
        common.switchesWindows(1);
        common.locationShouldContain("kampanya-kosullari");
        common.waitUntilElementIsVisible("all_campaigns_banner_image");
    }

    /**
     * User should be redirected to campaigns page.
     */
    @Step("User should be redirected to campaigns page")
    public void userShouldBeRedirectedToCampaignsPage() {
        common.locationShouldBe(systemUtils.readEnv("all_campaigns"));
    }

    /**
     * Logging in from all campaigns page.
     */
    @Step("User clicks the login button from all campaigns page")
    public void userClicksTheLoginButtonFromAllCampaignsPage() {
        common.scrollToElement("homepage_profile_icon");
        common.waitUntilElementIsVisible("homepage_login_buton");
        common.clickElementDota("homepage_login_buton");
        common.waitUntilPageLoaded();
        common.locationShouldBe(systemUtils.readEnv("all_campaigns_login_url"));
    }

    /**
     * Logging in from all campaigns page resp.
     */
    @Step("User clicks the login button from all campaigns page resp")
    public void userClicksTheLoginButtonFromAllCampaignsPageResp() {
        common.clickElementDota("homepage_profile_icon");
        common.waitUntilPageLoaded();
        common.locationShouldBe(systemUtils.readEnv("all_campaigns_login_url"));
    }

    /**
     * Left menu click from all campaigns page.
     */
    @Step("User should be able to click the left menu on the campaign page")
    public void userShouldBeAbleToClickTheLeftMenuOnTheCampaignPage() {
        common.clickWebElementAccordingToText("all_campaigns_left_menu", "Size Özel");
        common.clickWebElementAccordingToText("all_campaigns_left_menu", "Ekstra İndirimler");
        common.clickWebElementAccordingToText("all_campaigns_left_menu", "Banka Kampanyaları");
        common.clickWebElementAccordingToText("all_campaigns_left_menu", "Yıldızlar Geçidi");
        common.clickWebElementAccordingToText("all_campaigns_left_menu", "Özel Marka İşbirlikleri");
        common.clickWebElementAccordingToText("all_campaigns_left_menu", "Haftanın Keşifleri");
        common.clickWebElementAccordingToText("all_campaigns_left_menu", "Hediyeli Ürünler");
    }


    /**
     * Selects available campaign if given campaign name contains.
     *
     * @param campaignName campaign name
     */
    @Step("User should be able to select <campaignName> campaign")
    public void userShouldBeAbleToClickTheLeftMenuOnTheCampaignPageResp(final String campaignName) {
        common.findElementDota("all_campaigns_div").click();
        common.waitUntilElementIsVisible("selectable_campaign_list");
        common.clickWebElementAccordingToTextContains("selectable_campaign_list_links", campaignName);
        common.waitUntilPageLoaded();
    }


    /**
     * Select see all campaigns in hamburger menu content.
     *
     * @param selectedButton campaign name
     */
    @Step("User should be able to select <selectedButton> button")
    public void userOnTheCampaignPageResp(final String selectedButton) {
        common.waitUntilPageLoaded();
        JavascriptExecutor executor = (JavascriptExecutor) Driver.getWebDriver();
        executor.executeScript("arguments[0].click();", common.findElementDota(selectedButton));
    }
}
