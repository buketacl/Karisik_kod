package com.gg.selenium.steps;

import com.gg.selenium.base.Common;
import com.gg.selenium.data.UserLoader;
import com.gg.selenium.data.UserRepository;
import com.gg.selenium.models.User;
import com.gg.selenium.utils.LoginController;
import com.gg.selenium.utils.SystemUtils;
import com.thoughtworks.gauge.Step;
import com.thoughtworks.gauge.datastore.ScenarioDataStore;
import org.springframework.stereotype.Component;

/**
 * Implements steps definitions related to Login Page.
 */
@Component
public class LoginSteps {

  private final Common common;
  private final SystemUtils systemUtils;

  /**
   * User service.
   */
  private final UserLoader userRepository;

  /**
   * Instantiates a new Login steps.
   *
   * @param common
   * @param systemUtils
   * @param userLoader  the user loader
   */
  public LoginSteps(final Common common, final SystemUtils systemUtils,
      final UserLoader userLoader) {
    this.common = common;
    this.systemUtils = systemUtils;
    this.userRepository = userLoader;
  }

  /**
   * User logs in with username.
   *
   * @param userSet The name of the user in the userset, e.g. ADDRESS_WEB.
   */
  @Step("User logs in with username <USERSET>")
  public void userEntersUserName(final String userSet) {
    User user = this.userRepository.getUser(userSet);
    common.inputText("username_input", user.getUsername());
    common.inputText("password_input", user.getPassword());
    common.clickElementDota("login_page_login_button");
    common.waitUntilElementIsVisible("search_bar_search_button");
  }

  /**
   * Fills in the user's password.
   */
  @Step("User enters password")
  public void userEntersPassword() {
    fillsPassword();
  }

  /**
   * Fills the password come from the Login Controller.
   */
  public void fillsPassword() {
    @SuppressWarnings("SuspiciousMethodCalls")
    User user = UserRepository.USERS.get(ScenarioDataStore.get(LoginController.USER_ID));
    common.findElementDota("password_input").sendKeys(user.getPassword());
  }

  /**
   * User clicks login button for see user information page such as user addresses ,user bank
   * account.
   */
  @Step("User clicks login button for see user information page")
  public void userClicksLoginButtonForUserInformationPage() {
    common.clickElementDota("login_page_login_button");
    common.waitUntilPageLoaded();
    common.locationShouldBe(systemUtils.readEnv("my_addresses"));
  }

  /**
   * Chooses the guest user setting and continues with random email.
   */
  @Step("User skips login and continue as guest user")
  public void skipLoginAndContinueAsGuestUser() {
    common.clickElementDota("continue_as_guest_button");
    common.locationShouldBe(systemUtils.readEnv("funnel_address_info"));
  }

  /**
   * User should be able to  logs in with facebook credentials.
   */
  @Step("User should be able to logs in with facebook credentials")
  public void userLogsInWithFacebookCredentials() {
    User user = this.userRepository.getUser("FACEBOOK");
    common.clickElementDota("fb_login_button");
    common.waitUntilPageLoaded();
    common.switchesWindows(1);
    common.inputText("fb_email_input", user.getMail());
    common.inputText("fb_password_input", user.getPassword());
    common.findElementDota("fb_login_submit").click();
    common.switchesWindows(0);
    common.disablePopups();
    common.waitUntilPageLoaded();
    common.locationShouldBe(systemUtils.readEnv("gittigidiyor"));

  }

}
