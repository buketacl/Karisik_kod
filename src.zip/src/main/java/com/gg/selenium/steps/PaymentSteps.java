package com.gg.selenium.steps;

import com.gg.selenium.base.Common;
import com.gg.selenium.driver.Driver;
import com.gg.selenium.enums.CardType;
import com.gg.selenium.utils.SystemUtils;
import com.thoughtworks.gauge.Step;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;


/**
 * Implements steps definitions related to Payment Page.
 */
@Component
public class PaymentSteps {

    private final Common common;
    private final SystemUtils systemUtils;

    public PaymentSteps(final Common common, final SystemUtils systemUtils) {
        this.common = common;
        this.systemUtils = systemUtils;
    }

    /**
     * This method is used for fill payment information.
     *
     * @param cardType       BUSINESS or PERSONAL
     * @param cardHolderName Cart owner
     * @param cvc            Cart cvc
     * @param exMonth        Cart expire moth
     * @param exYear         Cart expire year
     */
    @Step("User should be able to fill in the payment information <cardType> <cardHolderName> <cvc> <exMonth> <exYear>")
    public void userFillsPaymentInformation(final CardType cardType, final String cardHolderName, final String cvc,
                                            final String exMonth, final String exYear) {
        common.refresh();
        common.waitUntilPageLoaded();
        String cardNumber = systemUtils.readEnv(cardType.toString());

        common.inputText("credit_card_number", cardNumber);
        common.inputText("credit_card_holder_name", cardHolderName);
        common.inputText("credit_card_cvc", cvc);

        common.getDropdownElement("credit_card_expire_month").selectByValue(exMonth);
        common.getDropdownElement("credit_card_expire_year").selectByValue(exYear);

    }

    /**
     * User clicks "Alışverişi Tamamla" button.
     * checks whether the user has landed on the Payment page.
     */
    @Step("User clicks complete shopping button")
    public void userClicksCompleteShoppingButton() {
        common.clickElementDota("payment_page_select_address_continue");
        common.waitUntilTitleContains("Ödeme Bilgileri - GittiGidiyor");

    }

    /**
     * Confirms that installment options are not visible and restricted installment info is visible.
     * Debit card and Personal card has different restricted installment text and has different cssSelector.
     *
     * @param cardType CardType is card type such as DEBIT or PERSONAL.
     */
    @Step("User should see restricted installment warning <cartType>")
    public void userShouldSeeRestrictedInstallmentWarning(final CardType cardType) {
        common.waitUntilElementIsVisible("installment_restricted_container");
        checkIfRestrictedInstallmentWarningVisibleAccordingToCard(cardType);
    }

    /**
     * Used for controlling restricted installment warning according to card type.
     *
     * @param cardType CartType is  a card type such as DEBIT or PERSONAL.
     */
    private void checkIfRestrictedInstallmentWarningVisibleAccordingToCard(final CardType cardType) {
        String warningCss;
        String expectedWarningText;
        if (cardType.equals(CardType.DEBIT)) {
            warningCss = "debit_card_restricted_info";
            expectedWarningText = "Kartınıza uygun taksit bulunmamaktadır.";
        } else {
            warningCss = "personal_card_restricted_info";
            expectedWarningText = "Sepetinizde taksit seçeneklerini kısıtlayan ürün var.";
        }
        String actualWarningText = common.findElementDota(warningCss).getText();
        Assertions.assertEquals(expectedWarningText, actualWarningText);
    }

    /**
     * User clicks "Yeni Adres Ekle" button.
     * checks whether the user sees add new address form.
     */
    @Step("User clicks add new address button on payment funnel")
    public void userClicksAddNewAddressPaymentPage() {
        common.clickElementDota("payment_page_address_add_button");
        common.waitUntilElementIsVisible("payment_page_address_title_box");
    }


    /**
     * This method is used for click given installment types .
     *
     * @param installmentType The installment option(s)
     *                        example usage: User clicks all given installment options "3 Taksit,6 Taksit,9 Taksit"
     *                        : User clicks all given installment options "3 Taksit"
     */
    @Step("User clicks all given installment options <installmentOptions>")
    public void userClicksAllGivenInstallmentTypes(final String installmentType) {
        common.scrollToElement("footer_responsive");
        String[] givenInstallmentOptions = installmentType.split(",");
        List<WebElement> webElementList = common.findElementsDota("installment_names");
        for (String givenOption : givenInstallmentOptions) {
            common.clickGivenInstallmentOptionDota(webElementList, givenOption);
        }
    }


    /**
     * User Checks default containers on payment page.
     */
    @Step("User checks default containers on payment page")
    public void userChecksPaymentDefaultContainers() {
        String[] containersCssKeys = {"total_summary_container", "total_price",
                "shopping_summary_container"};
        for (String key : containersCssKeys) {
            common.waitUntilElementIsVisible(key);
        }
    }

    /**
     * User should see 3D checkbox checked by default.
     */
    @Step("User should see 3D checkbox checked by default")
    public void userShouldSee3DCheckboxCheckedByDefault() {
        common.waitUntilElementIsVisible("payment_3d_checkbox");
        common.waitUntilPageContainsElement("payment_3d_checkbox_status").isSelected();
    }

    /**
     * Clicks contract checkbox.
     */
    @Step("User accepts contracts")
    public void userAcceptsContrats() {
        common.checkCheckBox("payment_contract", "payment_contract_check_box");
    }

    /**
     * Compares given button text and actual button text.
     *
     * @param givenButtonText Button text
     */
    @Step("User controls button text is <buttonText>")
    public void userControlsButtonTextIs(final String givenButtonText) {
        String buttonText = common.findElementDota("buy_product_button").getText();
        assertThat("Button text does not match with given text", givenButtonText.equals(buttonText));
    }

    /**
     * Clicks pay button on payment page.
     */
    @Step("User clicks pay button")
    public void userClicksPayButton() {
        scrollToElementFireFox("payment_summary_footer_content");
        common.clickElementDota("buy_product_button");
        common.waitUntilPageLoaded();
    }

    /**
     * Controls Bkm page redirection and expects GittiGidiyor text.
     */
    @Step("User should see Bkm page")
    public void userShouldSeeBkmPage() {
        Driver.getDriverWait().until(ExpectedConditions.urlContains("bkmexpress"));
        common.waitUntilPageContainsElement("bkm_page_shop_info");
    }

    /**
     * Controls Garanti page redirection and expects GittiGidiyor text.
     */
    @Step("User should see Garanti page")
    public void userShouldSeeGarantiPage() {
        Driver.getDriverWait().until(ExpectedConditions.urlContains("garanti"));
        common.waitUntilPageContainsElement("garanti_general_tab");
    }

    /**
     * Clicks payment tab on payment page.
     */
    @Step("User clicks <paymentTab> for web")
    public void userClicksPaymentTabForWeb(final String paymentTab) {
        common.clickElementDota(paymentTab);
        common.waitUntilElementIsVisible(paymentTab + "_info");
    }

    /**
     * Controls Ykb page redirection and expects GittiGidiyor logo.
     */
    @Step("User should see Ykb page")
    public void userShouldSeeYkbPage() {
        Driver.getDriverWait().until(ExpectedConditions.urlContains("yapikredi"));
        common.waitUntilPageContainsElement("ykb_gg_logo");
    }

    /**
     * Clicks given tab on payment page for resp.
     */
    @Step("User clicks <paymentTab> for resp")
    public void userClicksPaymentTabForResp(final String paymentTab) {
        common.clickElementDota("all_payment_options_resp");
        common.clickElementDota(paymentTab);
        common.waitUntilElementIsVisible(paymentTab + "_info");
    }

    /**
     * Scroll to element by locator for firefox
     * Usage: scrolTooElement(css, "homepage_buynow_buton")
     *
     * @param locator The locator string
     */
    public void scrollToElementFireFox(final String locator) {
        WebElement webElement = common.findElementDota(locator);
        ((JavascriptExecutor) Driver.getWebDriver()).executeScript("arguments[0].scrollIntoView();", webElement);
        Driver.getActions().moveToElement(webElement).perform();
    }

    /**
     * Clicks bkm go to previous page button.
     */
    @Step("User clicks previous page button for bkmexpress")
    public void userClicksPreviousPageButtonForBkmexpress() {
        common.clickElementDota("bkm_page_previous");
    }
}
