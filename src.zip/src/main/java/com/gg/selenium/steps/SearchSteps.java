package com.gg.selenium.steps;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;

import com.gg.selenium.base.Common;
import com.gg.selenium.exceptions.RestException;
import com.gg.selenium.services.ProductHelperService;
import com.gg.selenium.services.responses.ProductHelperResponse;
import com.gg.selenium.utils.SystemUtils;
import com.thoughtworks.gauge.Step;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.springframework.stereotype.Component;

/**
 * Implements steps definitions related to Search Page.
 */
@Component
public class SearchSteps {

    private final Common common;
    private final SystemUtils systemUtils;
    private final ProductHelperService productHelper;

    /**
     * Min price for product price range on srp.
     */
    public static final int MIN_PRICE = 50;
    /**
     * Max price for product price range on srp.
     */
    public static final int MAX_PRICE = 100;

    public SearchSteps(final Common common, final SystemUtils systemUtils, final ProductHelperService productHelper) {
        this.common = common;
        this.systemUtils = systemUtils;
        this.productHelper = productHelper;
    }

    /**
     * User searches the given text by typing the text in the search box.
     *
     * @param keyword the keyword to searched
     */
    @Step("User searches for <keyword>")
    public void search(final String keyword) {

        common.inputText("search_bar_input", keyword);
        common.clickElementDota("search_bar_search_button");

        WebElement infoContainer = common.findElementDota("search_result_page_info_container");
        String info = infoContainer.getText();

        String errorMessage = String.format("Search result page does not contain the text '%s'", keyword);
        assertThat(errorMessage, info, containsString(keyword));
    }

    /**
     * User selects the first product in the search result page.
     */
    @Step("User select first product")
    public void userSelectFirstProductCheckInfo() {
        WebElement firstWebElement = common.returnsWebElementAccordingToIndex("search_result_page_item", 0);

        String tempCss = systemUtils.readEnv("search_result_page_product_title");
        String searchResultPageTitle = firstWebElement.findElement(By.cssSelector(tempCss)).getText().trim();
        clickFirstProduct();

        String productPageTitle = common.findElementDota("spp_product_page_title").getText().trim();

        assertThat(searchResultPageTitle, equalTo(productPageTitle));
    }

    /**
     * User goes to product with id by using url.
     *
     * @param productName the product name
     */
    @Step("User goes to product page with productId <productName>")
    public void userGoesToProductPageWithId(final String productName) throws RestException {
        final Optional<ProductHelperResponse> optionalProduct = productHelper.getTestProductId(productName);
        if (!optionalProduct.isPresent()) {
            throw new RestException("Unable to product id from dota product helper: " + productName);
        }

        common.goToCustomizedUrl("urun_gg", optionalProduct.get().getProductId());
        common.waitUntilPageContainsElement("product_photo");
    }

    /**
     * Clicks the first product in the Search Result Page.
     */
    public void clickFirstProduct() {
        common.returnsWebElementAccordingToIndex("search_result_page_item", 0).click();
        common.waitUntilPageLoaded();
    }

    /**
     * User Check breadcrumb contain given Text.
     *
     * @param breadcrumbText category name.
     */
    @Step("User should see <breadcrumbText> text at breadcrumb")
    public void userShouldSeeBreadcrumbText(final String breadcrumbText) {
        common.waitUntilElementContainsText(breadcrumbText, "breadcrumb_list");
    }

    /**
     * User goes to "CUSTOM" product category.
     *
     * @param categoryEndpointLocator category locator name.
     */
    @Step("User goes to <categoryEndpointLocator> category")
    public void userGoesToGivenCategory(final String categoryEndpointLocator) {
        common.goToUrl(systemUtils.readEnv(categoryEndpointLocator));
    }

    /**
     * @param locatorKey : CssSelector to search within each result page element on srp.
     * @param screenSize : Screen size to find tests run in witch screen (Web or Resp)
     */
    public void checkIfWebElementsVisibleOnSrp(final String locatorKey, final String screenSize) {
        boolean isWebElementVisible;
        WebElement sellerBadge;
        String cssSelector = systemUtils.readEnv(locatorKey);
        if ("Web".equals(screenSize)) {
            for (WebElement srpProductOnFirstPage : common.findElementsDota("search_result_page_item")) {
                try {
                    sellerBadge = srpProductOnFirstPage.findElement(By.cssSelector(cssSelector));
                    isWebElementVisible = sellerBadge.isDisplayed();
                    Assertions.assertTrue(isWebElementVisible, "WebElement is not visible");
                } catch (NoSuchElementException e) {
                    WebElement productTitle = srpProductOnFirstPage.findElement(By.cssSelector(
                            systemUtils.readEnv("search_result_page_product_title")));
                    String message = String.format("'%s' product doesn't contain '%s' css",
                            productTitle.getText(), cssSelector);
                    throw new NoSuchElementException(message, e);
                }
            }
        } else {
            for (WebElement srpProductOnFirstPage : common.findElementsDota("search_result_page_item_resp_nucleus")) {
                try {
                    sellerBadge = srpProductOnFirstPage.findElement(By.cssSelector(cssSelector));
                    isWebElementVisible = sellerBadge.isDisplayed();
                    Assertions.assertTrue(isWebElementVisible, "WebElement is not visible");
                } catch (NoSuchElementException e) {
                    WebElement productTitle = srpProductOnFirstPage.findElement(By.cssSelector(
                            systemUtils.readEnv("srp_product_title")));
                    String message = String.format("'%s' product doesn't contain '%s' css",
                            productTitle.getText(), cssSelector);
                    throw new NoSuchElementException(message, e);
                }
            }
        }
    }


    /**
     * Removes the decimal part of a given product price.
     * If product price is 109,32 TL then 109 is returned
     *
     * @param productPrice ProductPrice as String
     * @return Price as int with decimal part removed
     */
    public int removeDecimalPart(final String productPrice) {
        String productPriceWithoutDecimalPart = productPrice.split(",")[0];
        return Integer.parseInt(productPriceWithoutDecimalPart);
    }

    /**
     * User clicks second hand filter.
     */
    @Step("User clicks second hand filter")
    public void userClicksSecondHandFilter() {
        common.waitUntilPageContainsElement("srp_second_hand_label");
        common.clickElementDota("srp_second_hand_label");
    }


    /**
     * User selects first product on srp.
     */
    @Step("User selects first product on srp")
    public void userSelectsFirstProductOnSrp() {
        clickFirstProduct();
    }

    /**
     * Writes <firstThreeCharacterOfKeyword> to search bar.
     *
     * @param firstThreeCharactersOfKeyword The first three character of keyword.
     */
    @Step("User writes <firstThreeCharacterOfKeyword> to search bar")
    public void userWritesFirstThreeCharactersOfKeyword(final String firstThreeCharactersOfKeyword) {
        common.inputText("search_bar_input", firstThreeCharactersOfKeyword);

    }

    /**
     * User should see autocomplete suggestions.
     */
    @Step("User should see autocomplete suggestions")
    public void userShouldSeeAutoCompleteSuggestions() {
        common.waitUntilElementIsVisible("auto_complete_list");
    }


    /**
     * User should be able to see super fiyatlar badges on srp <screenSize>
     *
     * @param screenSize The screen size which is should be Web or Resp
     */
    @Step("User should be able to see super fiyatlar badges on srp <screenSize>")
    public void userShouldBeAbleToSeeSuperFiyatlarOnSrp(final String screenSize) {
        checkIfWebElementsVisibleOnSrp("super_fiyatlar_badge", screenSize);
    }

    /**
     * User should be able to see <freeShippingText> badge on srp first item for resp
     *
     * @param freeShippingText The free shipping text which is should be visible on srp
     */
    @Step("User should be able to see <freeShippingText> badge on srp first item for resp")
    public void userShouldBeAbleToSeeFreeShippingOnSrp(final String freeShippingText) {
        boolean isContains = true;
        List<WebElement> webElementList = common.findElementsDota("product_cart_badges");
        if (!webElementList.get(0).getText().trim().contains(freeShippingText)) {
            isContains = false;
        }
        Assertions.assertTrue(isContains, "SRP first item doesn't contain free shipping text");
    }

    /**
     * User sees oppo products on srp.
     */
    @Step("User sees oppo products on srp")
    public void userSeesIphoneProductsOnSrp() {
        common.goToUrl(systemUtils.readEnv("oppo_searched_with_quarry"));
        common.waitUntilPageNotContainsElement("products_stars_on_srp");
        common.waitUntilElementIsVisible("products_stars_on_srp");
    }


    /**
     * User clicks given main filter.
     *
     * @param filterName given main filter such as POPULER FILTRE , FIYAT  etc.
     */
    @Step("User clicks <filterName> filter for resp")
    public void userClicksGivenMainFilter(final String filterName) {
        common.clickElementDota("srp_filter_button_resp");
        common.waitUntilElementIsVisible("srp_left_filter_resp");
        List<WebElement> webElementList = common.findElementsDota("srp_left_filter_sections");
        for (WebElement webElement : webElementList) {
            String filterSelectionText = webElement.getText();
            if (filterSelectionText.equals(filterName)) {
                webElement.click();
            }
        }

    }

    /**
     * User should be able to see super fiyatlar badges on srp <screenSize>
     *
     * @param screenSize
     */
    @Step("User should be able to see product stars on srp <screenSize>")
    public void userShouldBeAbleToSeeProductStarsOnSrp(final String screenSize) {
        checkIfWebElementsVisibleOnSrp("products_stars_on_srp", screenSize);
    }

    /**
     * User clicks free-shipping filter for resp.
     */
    @Step("User clicks free shipping filter for resp")
    public void userClicksSubCatForResp() {
        common.clickElementDota("free_shipping_filter_resp");
        common.waitUntilPageLoaded();
    }

    /**
     * User clicks guided filter according to given text.
     *
     * @param guidedFilterText given text
     */
    @Step("User clicks <guidedFilterText> guided filter")
    public void userClicksGuidedFilter(final String guidedFilterText) {
        common.clickWebElementAccordingToText("guided_filter_options", guidedFilterText);
        common.waitUntilPageLoaded();
        int indexSubString = guidedFilterText.indexOf(':') + 1;
        common.waitUntilElementContainsText(guidedFilterText.substring(indexSubString), "your_choices");

    }

    /**
     * User clicks remove to guided filter on srp.
     */
    @Step("User clicks remove to guided filter")
    public void userClicksRemoveToGuidedFilter() {
        common.clickElementDota("remove_guided_filter");
        common.waitUntilPageNotContainsElement("your_choices");
    }


    /**
     * Controls text in the bullet field of the key feature.
     *
     * @param keyFeatureText key feature bullet area.
     */
    @Step("User should see their chosen filter in key feature area <key feature text>")
    public void userShouldSeeGuidedFilterIsCorrect(final String keyFeatureText) {
        int indexSubString = keyFeatureText.indexOf(':') + 1;
        common.waitUntilElementContainsText(keyFeatureText.substring(indexSubString), "your_choices");
    }

    /**
     * User clicks category for resp.
     *
     * @param category given category such as bilgisayar-bilesenleri.
     */
    @Step("User clicks <category> category from hamburger menu resp")
    public void userClicksCategoryFromHamburgerMenuForResp(final String category) {
        common.clickWebElementAccordingToText("srp_category", category);
    }

    /**
     * User clicks overseas-shopping for resp.
     *
     */
    @Step("User clicks overseas shopping from hamburger menu resp")
    public void userClicksOverseasShippingFromHamburgerMenuForResp() {
        common.clickElementDota("overseas_shopping_hamburger");
    }

    /**
     * Url should contains given name.
     *
     * @param name given endpoint name
     */
    @Step("Url should contains <name> endpoint name")
    public void urlShouldContainsName(final String name) {
        common.waitUntilElementIsVisible("search_result_page_item_resp_nucleus");
        common.locationShouldContain(name.toLowerCase());
    }

    /**
     * Clicks hamburger menu for resp.
     */
    @Step("User clicks hamburger menu for resp")
    public void userClicksHamburgerMenuForResp() {
        common.goToUrl(systemUtils.readEnv("gittigidiyor"));
        common.clickElementDota("hamburger_menu");
        common.waitUntilElementIsVisible("hamburger_menu_area");
        common.clickWebElementAccordingToTextContains("see_all_options", "Tümünü Gör");
    }
}
