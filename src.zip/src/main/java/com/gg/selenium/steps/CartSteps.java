package com.gg.selenium.steps;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;

import com.gg.selenium.base.Common;
import com.gg.selenium.data.UserRepository;
import com.gg.selenium.exceptions.RestException;
import com.gg.selenium.models.User;
import com.gg.selenium.services.CartServiceFacade;
import com.gg.selenium.services.ProductHelperService;
import com.gg.selenium.services.responses.ProductHelperResponse;
import com.gg.selenium.utils.LoginController;
import com.gg.selenium.utils.SystemUtils;
import com.thoughtworks.gauge.Step;
import com.thoughtworks.gauge.datastore.ScenarioDataStore;
import java.util.List;
import java.util.Optional;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Implements steps definitions related to Cart Page.
 */
@Component
public class CartSteps {

  private static final Logger LOGGER = LoggerFactory.getLogger(CartSteps.class);

  private final Common common;
  private final SystemUtils systemUtils;
  private final CartServiceFacade cartServiceFacade;
  private final ProductHelperService productHelper;

  public CartSteps(final Common common, final SystemUtils systemUtils,
      final CartServiceFacade cartServiceFacade, final ProductHelperService productHelper) {
    this.common = common;
    this.systemUtils = systemUtils;
    this.cartServiceFacade = cartServiceFacade;
    this.productHelper = productHelper;
  }

  /**
   * User clicks "Alışverişi Tamamla" button and checks whether the user has landed on Cargo Page.
   */
  @Step("User proceeds to checkout")
  public void userProceedsToCheckout() {
    common.goToUrl(systemUtils.readEnv("cart_url"));
    common.refresh();
    userIgnoresDiscountIfAvailable();
    common.clickElementDota("cart_complete_shopping");
    common.waitUntilElementContainsText("Kargo teslim adresini seçin",
        "payment_page_address_info_title");

  }

  /**
   * User clicks "Alışverişi Tamamla" button and checks whether the user has landed on Cargo Page.
   */
  @Step("User proceeds to checkout for resp")
  public void userProceedsToCheckoutForResp() {
    common.goToUrl(systemUtils.readEnv("cart_url"));
    common.refresh();
    userIgnoresDiscountIfAvailable();
    common.scrollToElement("recommendation_container_on_cart");
    common.clickElementDota("cart_complete_shopping");
    common.waitUntilElementContainsText("Kargo teslim adresini seçin",
        "payment_page_address_info_title");
  }

  /**
   * Adds product with product amount and product name with rest request.
   *
   * @param productName   Product name
   * @param productAmount product amount
   */
  @Step("Adds product(s) to basket without variant with rest request <productName> <productAmount>")
  public void addProductWithRestRequest(final String productName, final String productAmount)
      throws RestException {
    User user = UserRepository.USERS.get(ScenarioDataStore.get(LoginController.USER_ID));
    cartServiceFacade.addProductByUsername(user.getUsername(), productName, productAmount);
  }

  /**
   * Adds product with product amount and product name with zf request.
   *
   * @param productName   Product name
   * @param productAmount product amount
   */
  @Step("Adds product(s) without variant for guest user by using zf request <productName> <productAmount>")
  public void addProductWithZfRequest(final String productName, final String productAmount) {
    final Optional<ProductHelperResponse> productHelperResponse = productHelper
        .getTestProductId(productName);
    if (productHelperResponse.isPresent()) {
      String productId = productHelperResponse.get().getProductId();
      String url =
          systemUtils.readEnv("add_basket_url") + "?id=" + productId + "&adet=" + productAmount;
      common.goToUrl(url, systemUtils.readEnv("cart_url"));
      common.refresh();
      common.waitUntilElementIsVisible("product_item_delete_button");
      String dataId = common.getProperty("product_item_delete_button", "data-id");
      assertThat("Product could not be added ", dataId, containsString(productId));
    } else {
      LOGGER.error("Unable to get a product ID of {} from dota-product-helper.", productName);
    }
  }

  /**
   * Buy now product with product amount and product name with zf request.
   *
   * @param productName   Product name
   * @param productAmount product amount
   */
  @Step("Buy now product(s) without variant by using zf request <productName> <productAmount>")
  public void buyNowProductWithZfRequest(final String productName, final String productAmount) {
    final Optional<ProductHelperResponse> productHelperResponse = productHelper
        .getTestProductId(productName);
    if (productHelperResponse.isPresent()) {
      String productId = productHelperResponse.get().getProductId();
      String url = systemUtils.readEnv("add_basket_url") + "?id=" + productId
          + systemUtils.readEnv("buy_now") + productAmount;
      common.goToUrl(url, systemUtils.readEnv("funnel_address_info"));
    } else {
      LOGGER.error("Unable to get a product ID of {} from dota-product-helper.", productName);
    }
  }

  /**
   * User clicks "Alışverişi Tamamla" button and checks whether the user has landed on Guest login
   * page.
   */
  @Step("User proceeds to checkout as guest user")
  public void userProceedsToCheckoutGuest() {
    common.clickElementDota("cart_complete_shopping");
    common.waitUntilElementContainsText("Giriş Yap", "guest_user_login_page_header");
  }

  /**
   * Adds random product to basket with productId by using zf request.
   * <p>
   * This method created for Payment Should Saved Card Come First testCase selectedIndexProductId
   * variable comes from userClicksRandomProduct method.
   */
  @Step("User adds random product to shopping cart without variant by using productId")
  public void addRandomProductWithoutVariantFromDataStoreWithId() {
    String returnedProductId = ScenarioDataStore.get("selectedIndexProductId").toString();
    String url = systemUtils.readEnv("add_basket_url") + "?id=" + returnedProductId + "&adet=" + 1;
    common.goToUrl(url, systemUtils.readEnv("cart_url"));
    String dataId = common.getProperty("product_item_delete_button", "data-id");
    assertThat("Product couldn't added ", dataId, containsString(returnedProductId));
  }

  /**
   * Clears basket.
   */
  @Step("User clears basket")
  public void userClearsBasket() {
    common.goToUrl(systemUtils.readEnv("cart_url"));
    common.refresh();
    List<WebElement> productList;
    do {
      common.waitUntilAjaxLoaded();
      productList = common.findElementsDota("product_item_delete_button");
      if (!productList.isEmpty()) {
        productList.get(0).click();
      }
    } while (!productList.isEmpty());

    String cartMessage = common.findElementDota("cart_message_after_product_delete").getText();
    assertThat("Product couldn't delete", cartMessage,
        is(equalTo("Sepetinizde ürün bulunmamaktadır.")));

    LOGGER.info("No more product to delete");
  }

  /**
   * User should see discount_box and discount_selected_class.
   */
  @Step("User should see discount on shopping cart")
  public void userShouldSeeDiscountOnShoppingCart() {
    common.goToUrl(systemUtils.readEnv("cart_url"));
    common.waitUntilElementIsVisible("discount_box");
    common.waitUntilElementIsVisible("discount_selected_class");
  }

  /**
   * User should not see any discount_selected_class.
   */
  @Step("User should not see any discount on shopping cart")
  public void userShouldNotSeeAnyDiscountOnShoppingCart() {
    common.goToUrl(systemUtils.readEnv("cart_url"));
    common.waitUntilPageNotContainsElement("discount_selected_class");
  }

  /**
   * User ignores discount if discount available.
   */
  public void userIgnoresDiscountIfAvailable() {
    if (common.waitUntilPageContainsElement("discount_box").isDisplayed()) {
      common.getDropdownElement("discount_box").selectByValue("0");
      common.waitUntilAjaxLoaded();
    }
  }

}
