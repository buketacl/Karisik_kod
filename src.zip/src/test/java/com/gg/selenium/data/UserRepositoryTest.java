package com.gg.selenium.data;

import com.gg.selenium.models.User;
import com.google.common.collect.Sets;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.*;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

class UserRepositoryTest {

    private UserRepository prod;
    private UserRepository prodResp;
    private UserRepository manualProd;
    private UserRepository manualProdResp;
    private UserRepository staging;
    private UserRepository stagingResp;
    private Set<String> exceptions = new HashSet<>(){{
        add("LISTING_MEGA_USER");
        add("qa_selmega");
    }};

    @BeforeEach
    void setUp() {
        prod = new UserRepository("prod");
        prodResp = new UserRepository("prod-resp");
        manualProd = new UserRepository("manual_prod");
        manualProdResp = new UserRepository("manual_prod-resp");
        staging = new UserRepository("staging");
        stagingResp = new UserRepository("staging-resp");
    }

    @Test
    void getUserShouldReturnCorrectUserInformation() {
        UserRepository userRepository = new UserRepository("users");
        assertEquals(3, userRepository.getUsers().size());

        User firstUser = userRepository.getUser("ADD_TO_BASKET_FIXPACK_NEW_SPP");
        assertNotNull(firstUser);
        assertEquals("add_to_basket_fixpack_new_spp", firstUser.getUsername());
    }

    @Test
    void allUserSetsShouldHaveAllUsers() {
        assertListAreEqual(prod.getUsers().keySet(), prodResp.getUsers().keySet(), "prod and prod-resp");
        assertListAreEqual(prod.getUsers().keySet(), manualProd.getUsers().keySet(), "prod and manual_prod");
        assertListAreEqual(prod.getUsers().keySet(), manualProdResp.getUsers().keySet(), "prod and manual_prod-resp");
        assertListAreEqual(prod.getUsers().keySet(), staging.getUsers().keySet(), "prod and staging");
        assertListAreEqual(prod.getUsers().keySet(), stagingResp.getUsers().keySet(), "prod and staging-resp");
    }

    @Test
    void allUserSetsShouldHaveDifferentUserNames() {
        Set<String> prodUserNames = prod.getUsers().values().stream().map(User::getUsername).collect(Collectors.toSet());
        assertListAreDifferent(
                prodUserNames,
                prodResp.getUsers().values().stream().map(User::getUsername).collect(Collectors.toSet()),
                "prod - prod-resp"
        );

        assertListAreDifferent(
                prodUserNames,
                manualProd.getUsers().values().stream().map(User::getUsername).collect(Collectors.toSet()),
                "prod - manual-prod"
        );

        assertListAreDifferent(
                prodUserNames,
                manualProdResp.getUsers().values().stream().map(User::getUsername).collect(Collectors.toSet()),
                "prod - manual_prod-resp"
        );

        assertListAreDifferent(
                prodUserNames,
                staging.getUsers().values().stream().map(User::getUsername).collect(Collectors.toSet()),
                "prod - staging"
        );

        assertListAreDifferent(
                prodUserNames,
                stagingResp.getUsers().values().stream().map(User::getUsername).collect(Collectors.toSet()),
                "prod - staging-resp"
        );
    }

    private void assertListAreEqual(Set<String> set1, Set<String> set2, String setsCompared) {
        set1.removeAll(exceptions);
        set2.removeAll(exceptions);
        Set<String> diff = Sets.difference(set1, set2);

        String message = String.format("The usersets '%s' have some differing entries: %s", setsCompared, diff);
        assertTrue(diff.isEmpty(), message);
    }

    private void assertListAreDifferent(Set<String> set1, Set<String> set2, String setsCompared) {
        set1.removeAll(exceptions);
        set2.removeAll(exceptions);

        Set<String> intersection = Sets.intersection(set1, set2);
        String message = String.format("The userset '%s' have some common entries: %s", setsCompared, intersection);
        assertEquals(0, intersection.size(), message);
    }
}